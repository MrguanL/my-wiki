module.exports = {
  async activated() {

  },
  async deactivated() {

  },
  async init() {

  },
  async created() {

  },
  async updated() {

  },
  async deleted() {

  },
  async renamed() {

  },
  async getLocalLocation () {

  }
}
