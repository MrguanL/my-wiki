const _ = require('lodash')

/**
 * 生成微信分享图片URL
 * @param {Object} page - 页面对象
 * @param {Object} req - 请求对象，用于获取当前域名
 * @returns {String} - 图片URL
 */
function getWechatShareImage(page, req) {
  // 动态获取当前请求的完整URL基础部分
  const protocol = req.secure || req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http'
  const host = req.get('host')
  
  // 如果是外网域名，使用标准端口（微信分享需要）
  let baseUrl
  if (host && (host.includes('hyzx.heengy.cn') || host.includes('yourdomain.com'))) {
    const cleanHost = host.split(':')[0] // 移除端口号
    baseUrl = `${protocol}://${cleanHost}`
  } else {
    // 本地开发环境保持原有逻辑
    baseUrl = `${protocol}://${host}`
  }
  
  // 添加时间戳强制刷新微信缓存
  const timestamp = Math.floor(Date.now() / (1000 * 60 * 10)) // 每10分钟更新
  const image = `${baseUrl}/_assets/img/wechat/default.jpg?v=${timestamp}`
  
  return image
}

/**
 * 生成微信分享额外 Meta 标签
 * @param {Object} page - 页面对象
 * @param {Object} config - 站点配置
 * @param {String} image - 分享图片URL
 * @returns {String} - HTML meta 标签字符串
 */
function generateWechatMetaTags(page, config, image) {
  // 基础信息
  const title = page.title || 'Wiki.js'
  
  // 确保描述不为空，微信分享卡片需要描述
  let description = page.description || config.description
  if (!description || description.trim() === '') {
    description = `来自${config.title || '恒源知享'}的知识分享`
  }
  
  // 生成额外的微信分享标签（不包含基础og标签，避免重复）
  const metaTags = [
    `<!-- 微信分享专用标签 -->`,
    `<meta name="twitter:card" content="summary_large_image" />`,
    `<meta name="twitter:title" content="${_.escape(title)}" />`,
    `<meta name="twitter:description" content="${_.escape(description)}" />`,
    `<meta name="twitter:image" content="${image}" />`,
    `<meta name="twitter:image:width" content="1200" />`,
    `<meta name="twitter:image:height" content="630" />`,
    ``,
    `<!-- 微信兼容性增强标签 -->`,
    `<meta property="og:image:width" content="1200" />`,
    `<meta property="og:image:height" content="630" />`,
    `<meta property="og:image:type" content="image/jpeg" />`,
    `<meta property="og:image:alt" content="${_.escape(title)}" />`,
    `<meta property="og:locale" content="zh_CN" />`,
    ``,
    `<!-- 移动端和微信内置浏览器优化 -->`,
    `<meta itemprop="name" content="${_.escape(title)}" />`,
    `<meta itemprop="description" content="${_.escape(description)}" />`,
    `<meta itemprop="image" content="${image}" />`,
    `<meta name="application-name" content="${_.escape(config.title || '恒源知享')}" />`,
    `<meta name="msapplication-TileImage" content="${image}" />`,
    ``,
    `<!-- 微信分享强制刷新和兼容性 -->`,
    `<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />`,
    `<meta http-equiv="Pragma" content="no-cache" />`,
    `<meta http-equiv="Expires" content="0" />`,
    `<meta name="format-detection" content="telephone=no" />`,
    `<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />`,
    ``,
    `<!-- 微信分享专用标识 -->`,
    `<meta name="wechat-share" content="enabled" />`,
    `<meta property="qc:admins" content="" />`,
    `<meta property="wb:webmaster" content="" />`
  ]
  
  return metaTags.join('\n  ')
}

/**
 * 生成分享按钮 HTML
 * @param {String} url - 当前页面URL
 * @returns {String} - 分享按钮HTML
 */
function generateShareButton(url) {
  return `
    <div id="wechat-share-btn" style="position: fixed; top: 80px; right: 20px; z-index: 1000;">
      <!-- 微信环境显示分享按钮 -->
      <div id="wechat-share-buttons" style="display: flex; flex-direction: column; gap: 8px;">
        <button id="share-friend-button" onclick="shareToFriend()" title="分享给朋友" style="
          background: #1AAD19;
          color: white;
          border: none;
          padding: 8px 12px;
          border-radius: 6px;
          cursor: pointer;
          font-size: 13px;
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: 4px;
          box-shadow: 0 2px 6px rgba(26, 173, 25, 0.3);
          transition: all 0.2s ease;
          min-width: 100px;
          justify-content: center;
        " onmouseover="this.style.background='#179B16'" 
           onmouseout="this.style.background='#1AAD19'">
          💬 分享给朋友
        </button>
        <button id="share-moments-button" onclick="shareToMoments()" title="分享到朋友圈" style="
          background: #FF6B35;
          color: white;
          border: none;
          padding: 8px 12px;
          border-radius: 6px;
          cursor: pointer;
          font-size: 13px;
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: 4px;
          box-shadow: 0 2px 6px rgba(255, 107, 53, 0.3);
          transition: all 0.2s ease;
          min-width: 100px;
          justify-content: center;
        " onmouseover="this.style.background='#E55A2E'" 
           onmouseout="this.style.background='#FF6B35'">
          🌐 朋友圈
        </button>
        <!-- 调试按钮 -->
        <button id="debug-button" onclick="showDebugInfo()" title="调试信息" style="
          background: #666;
          color: white;
          border: none;
          padding: 6px 10px;
          border-radius: 4px;
          cursor: pointer;
          font-size: 12px;
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: 4px;
          transition: all 0.2s ease;
          justify-content: center;
        " onmouseover="this.style.background='#555'" 
           onmouseout="this.style.background='#666'">
          🔍 调试
        </button>
      </div>
      
      <!-- 非微信环境或默认按钮 -->
      <button id="share-button" onclick="handleShareClick()" title="点击复制链接" style="
        background: #4A90E2;
        color: white;
        border: none;
        padding: 10px 16px;
        border-radius: 8px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 6px;
        box-shadow: 0 2px 8px rgba(74, 144, 226, 0.3);
        transition: all 0.2s ease;
        min-width: 80px;
        justify-content: center;
      " onmouseover="this.style.background='#357ABD'; this.style.boxShadow='0 4px 12px rgba(74, 144, 226, 0.4)'" 
         onmouseout="this.style.background='#4A90E2'; this.style.boxShadow='0 2px 8px rgba(74, 144, 226, 0.3)'">
        🔗 <span id="share-text">分享</span>
      </button>
    </div>
    
    <!-- 调试信息显示区域 -->
    <div id="debug-info" style="
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(0,0,0,0.9);
      color: white;
      padding: 20px;
      border-radius: 8px;
      z-index: 10002;
      max-width: 90%;
      max-height: 80%;
      overflow: auto;
      font-family: monospace;
      font-size: 12px;
      line-height: 1.5;
      display: none;
    ">
      <button onclick="closeDebugInfo()" style="
        position: absolute;
        top: 10px;
        right: 10px;
        background: #ff4444;
        color: white;
        border: none;
        border-radius: 4px;
        padding: 5px 10px;
        cursor: pointer;
      ">关闭</button>
      <div id="debug-content"></div>
    </div>
    
    <style>
      #share-button:active {
        transform: scale(0.95) !important;
      }
      
      @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
      }
      
      .share-success {
        animation: pulse 0.3s ease-in-out;
      }
    </style>
    
    <!-- 添加vConsole移动端调试工具 -->
    <script src="https://unpkg.com/vconsole@latest/dist/vconsole.min.js"></script>
    <script>
      // 启用vConsole调试面板
      if (typeof window.VConsole !== 'undefined') {
        var vConsole = new window.VConsole();
        console.log('📱 vConsole调试面板已启用，点击右下角绿色按钮查看详细日志');
      }
      
      // 全局调试变量
      window.debugLogs = [];
      
      function debugLog(message, data = null) {
        const timestamp = new Date().toLocaleTimeString();
        const logEntry = {
          timestamp,
          message,
          data: data ? JSON.stringify(data, null, 2) : null
        };
        window.debugLogs.push(logEntry);
        console.log(\`[微信分享调试 \${timestamp}] \${message}\`, data || '');
        
        // 限制日志数量
        if (window.debugLogs.length > 50) {
          window.debugLogs = window.debugLogs.slice(-30);
        }
      }
      
      function isWechatBrowser() {
        const isWechat = /MicroMessenger/i.test(navigator.userAgent);
        debugLog('检测微信环境', { isWechat, userAgent: navigator.userAgent });
        return isWechat;
      }

      // 显示调试信息
      function showDebugInfo() {
        const debugDiv = document.getElementById('debug-info');
        const debugContent = document.getElementById('debug-content');
        
        const info = [
          '=== 微信分享调试信息 ===',
          \`时间: \${new Date().toLocaleString()}\`,
          \`是否微信环境: \${isWechatBrowser()}\`,
          \`UserAgent: \${navigator.userAgent}\`,
          \`WeixinJSBridge可用: \${typeof WeixinJSBridge !== 'undefined'}\`,
          \`当前URL: \${window.location.href}\`,
          \`页面标题: \${document.title}\`,
          \`页面描述: \${document.querySelector('meta[name="description"]')?.content || '无'}\`,
          '',
          '=== 分享图片检测 ===',
          \`协议: \${window.location.protocol}\`,
          \`主机: \${window.location.host}\`,
                     \`图片URL: https://\${window.location.host.split(':')[0]}/_assets/img/wechat/default.jpg\`,
          '',
          '=== Meta标签检测 ===',
          \`og:title: \${document.querySelector('meta[property="og:title"]')?.content || '无'}\`,
          \`og:description: \${document.querySelector('meta[property="og:description"]')?.content || '无'}\`,
          \`og:image: \${document.querySelector('meta[property="og:image"]')?.content || '无'}\`,
          \`og:url: \${document.querySelector('meta[property="og:url"]')?.content || '无'}\`,
          \`og:type: \${document.querySelector('meta[property="og:type"]')?.content || '无'}\`,
          \`og:site_name: \${document.querySelector('meta[property="og:site_name"]')?.content || '无'}\`,
          '',
          '=== 页面HTML源码检查 ===',
          \`HTML标题: \${document.head.querySelector('title')?.textContent || '无'}\`,
          \`Meta标签数量: \${document.head.querySelectorAll('meta').length}\`,
          \`OG标签数量: \${document.head.querySelectorAll('meta[property^="og:"]').length}\`,
          '',
          '=== 图片访问测试 ===',
          '正在测试图片URL...',
          '',
          '=== 最近调试日志 ==='
        ];
        
        // 添加最近的调试日志
        window.debugLogs.slice(-10).forEach(log => {
          info.push(\`[\${log.timestamp}] \${log.message}\`);
          if (log.data) {
            info.push(log.data);
          }
          info.push('');
        });
        
        // 测试图片访问
        const testImgUrl = \`https://\${window.location.host.split(':')[0]}/_assets/img/wechat/default.jpg\`;
        const testImg = new Image();
        testImg.onload = function() {
          debugLog('调试页面图片测试成功', { url: testImgUrl, width: this.width, height: this.height });
        };
        testImg.onerror = function() {
          debugLog('调试页面图片测试失败', { url: testImgUrl });
        };
        testImg.src = testImgUrl;
        
        debugContent.innerHTML = '<pre>' + info.join('\\n') + '</pre>';
        debugDiv.style.display = 'block';
      }
      
      function closeDebugInfo() {
        document.getElementById('debug-info').style.display = 'none';
      }

      // 分享给朋友
      function shareToFriend() {
        debugLog('开始分享给朋友 - 引导模式');
        
        if (!isWechatBrowser()) {
          debugLog('非微信环境，转为复制链接');
          handleShareClick();
          return;
        }
        
        // 微信环境：直接引导用户使用原生分享
        debugLog('微信环境，引导用户使用原生分享功能');
        showToast('💡 请点击右上角 "⋯" 选择 "发送给朋友"', 'info');
        
        // 记录分享参数供调试
        const protocol = 'https:';
        const host = window.location.host.split(':')[0];
        const imgUrl = protocol + '//' + host + '/_assets/img/wechat/default.jpg';
        
        debugLog('分享参数（供调试）', {
          title: document.title || '知识分享',
          link: protocol + '//' + host + window.location.pathname + window.location.search,
          img_url: imgUrl
        });
      }

      // 分享到朋友圈
      function shareToMoments() {
        debugLog('开始分享到朋友圈 - 引导模式');
        
        if (!isWechatBrowser()) {
          debugLog('非微信环境，转为复制链接');
          handleShareClick();
          return;
        }
        
        // 微信环境：直接引导用户使用原生分享
        debugLog('微信环境，引导用户使用原生分享功能');
        showToast('💡 请点击右上角 "⋯" 选择 "分享到朋友圈"', 'info');
        
        // 记录分享参数供调试
        const protocol = 'https:';
        const host = window.location.host.split(':')[0];
        const imgUrl = protocol + '//' + host + '/_assets/img/wechat/default.jpg';
        
        debugLog('朋友圈分享参数（供调试）', {
          title: document.title || '知识分享',
          link: protocol + '//' + host + window.location.pathname + window.location.search,
          img_url: imgUrl
        });
      }

      // 处理普通分享点击
      function handleShareClick() {
        const button = document.getElementById('share-button');
        const shareText = document.getElementById('share-text');
        
        if (isWechatBrowser()) {
          debugLog('微信环境下点击通用分享按钮，转为分享给朋友');
          shareToFriend();
          return;
        }
        
        debugLog('非微信环境，执行复制链接');
        const url = window.location.href;
        
        button.classList.add('share-success');
        shareText.textContent = '复制中...';
        
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(url).then(() => {
            debugLog('复制链接成功');
            showToast('✅ 链接已复制到剪贴板！', 'success');
            resetButton();
          }).catch(() => {
            debugLog('现代API复制失败，使用fallback');
            fallbackCopyTextToClipboard(url);
          });
        } else {
          debugLog('不支持现代API，使用fallback复制');
          fallbackCopyTextToClipboard(url);
        }
      }
      
      function fallbackCopyTextToClipboard(text) {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.top = "-9999px";
        textArea.style.left = "-9999px";
        textArea.style.opacity = "0";
        
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        textArea.setSelectionRange(0, 99999);
        
        try {
          const successful = document.execCommand('copy');
          if (successful) {
            debugLog('fallback复制成功');
            showToast('✅ 链接已复制到剪贴板！', 'success');
          } else {
            debugLog('fallback复制失败');
            showToast('❌ 复制失败，请手动复制链接', 'error');
          }
        } catch (err) {
          debugLog('fallback复制异常', err);
          showToast('❌ 复制失败，请手动复制链接', 'error');
        }
        
        document.body.removeChild(textArea);
        resetButton();
      }
      
      function resetButton() {
        setTimeout(() => {
          const button = document.getElementById('share-button');
          const shareText = document.getElementById('share-text');
          if (button && shareText) {
            button.classList.remove('share-success');
            shareText.textContent = '分享';
          }
        }, 300);
      }

      // 页面加载时初始化
      function initShareButtons() {
        const wechatButtons = document.getElementById('wechat-share-buttons');
        const defaultButton = document.getElementById('share-button');
        
        debugLog('初始化分享按钮');
        debugLog('环境检测', {
          isWechat: isWechatBrowser(),
          userAgent: navigator.userAgent,
          weixinJSBridge: typeof WeixinJSBridge !== 'undefined',
          url: window.location.href
        });
        
        if (isWechatBrowser()) {
          // 微信环境显示微信按钮，隐藏默认按钮
          if (wechatButtons) wechatButtons.style.display = 'flex';
          if (defaultButton) defaultButton.style.display = 'none';
          debugLog('显示微信分享按钮');
        } else {
          // 非微信环境显示默认按钮，隐藏微信按钮
          if (wechatButtons) wechatButtons.style.display = 'none';
          if (defaultButton) defaultButton.style.display = 'flex';
          debugLog('显示默认分享按钮');
        }
      }

      // 页面加载完成后初始化
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initShareButtons);
      } else {
        initShareButtons();
      }
      
      function showToast(message, type = 'success') {
        const existingToast = document.querySelector('.share-toast');
        if (existingToast) {
          existingToast.remove();
        }
        
        const toast = document.createElement('div');
        toast.className = 'share-toast';
        toast.textContent = message;
        
        let bgColor;
        switch (type) {
          case 'success':
            bgColor = '#10B981';
            break;
          case 'error':
            bgColor = '#EF4444';
            break;
          case 'info':
            bgColor = '#3B82F6';
            break;
          default:
            bgColor = '#10B981';
        }
        
        toast.style.cssText = \`
          position: fixed;
          top: 20px;
          right: 20px;
          background: \${bgColor};
          color: white;
          padding: 12px 20px;
          border-radius: 8px;
          z-index: 10001;
          font-size: 14px;
          font-weight: 500;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
          max-width: 300px;
          word-wrap: break-word;
          animation: slideInRight 0.3s ease-out;
        \`;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
          if (toast.parentNode) {
            toast.style.animation = 'slideOutRight 0.3s ease-in forwards';
            setTimeout(() => {
              if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
              }
            }, 300);
          }
        }, 3000);
      }
      
      // 添加动画样式
      if (!document.querySelector('#share-toast-styles')) {
        const style = document.createElement('style');
        style.id = 'share-toast-styles';
        style.textContent = \`
          @keyframes slideInRight {
            from {
              transform: translateX(100%);
              opacity: 0;
            }
            to {
              transform: translateX(0);
              opacity: 1;
            }
          }
          
          @keyframes slideOutRight {
            from {
              transform: translateX(0);
              opacity: 1;
            }
            to {
              transform: translateX(100%);
              opacity: 0;
            }
          }
        \`;
        document.head.appendChild(style);
      }
    </script>
  `
}

module.exports = {
  getWechatShareImage,
  generateWechatMetaTags,
  generateShareButton
} 