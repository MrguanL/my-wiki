const _ = require('lodash')

/**
 * 获取微信分享图片URL
 */
function getWechatShareImage(page, req) {
  const protocol = 'https:'
  let host = req.get('host')
  
  // 外网环境移除端口号
  if (host && host.includes('hyzx.heengy.cn')) {
    host = host.replace(':13000', '')
  }
  
  const baseUrl = `${protocol}//${host}`
  const image = `${baseUrl}/_assets/img/wechat/default.jpg`
  
  return image
}

/**
 * 生成微信分享 Meta 标签
 */
function generateWechatMetaTags(page, config, image) {
  const title = page.title || 'Wiki.js'
  
  // 确保描述不为空
  let description = page.description || config.description
  if (!description || description.trim() === '') {
    description = `来自${config.title || '恒源知享'}的知识分享`
  }
  
  const metaTags = [
    `<!-- 微信分享专用标签 -->`,
    `<meta name="twitter:card" content="summary_large_image" />`,
    `<meta name="twitter:title" content="${_.escape(title)}" />`,
    `<meta name="twitter:description" content="${_.escape(description)}" />`,
    `<meta name="twitter:image" content="${image}" />`,
    `<meta property="og:image:width" content="1200" />`,
    `<meta property="og:image:height" content="630" />`,
    `<meta property="og:image:type" content="image/jpeg" />`,
    `<meta property="og:locale" content="zh_CN" />`,
    `<meta itemprop="name" content="${_.escape(title)}" />`,
    `<meta itemprop="description" content="${_.escape(description)}" />`,
    `<meta itemprop="image" content="${image}" />`
  ]
  
  return metaTags.join('\n  ')
}

/**
 * 生成分享按钮
 */
function generateWechatShareButton(pageId, pageTitle, pageDescription, pageUrl) {
  return `
    <div id="wechat-share-container" style="
      position: fixed;
      right: 20px;
      top: 50%;
      transform: translateY(-50%);
      z-index: 1000;
    ">
      <!-- 海报分享按钮 -->
      <button id="share-btn" onclick="openSharePoster()" style="
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        padding: 8px 6px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
        box-shadow: 0 3px 12px rgba(102, 126, 234, 0.4);
        transition: all 0.3s ease;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 2px;
        width: 36px;
        height: 80px;
        justify-content: center;
        opacity: 0.9;
        line-height: 1;
      " title="生成分享海报，包含二维码和链接地址">
        <span style="font-size: 14px;">🎨</span>
        <span style="font-size: 10px;">分</span>
        <span style="font-size: 10px;">享</span>
        <span style="font-size: 10px;">海</span>
        <span style="font-size: 10px;">报</span>
      </button>
    </div>

    <script>
      const pageId = ${pageId};
      const pageTitle = "${pageTitle}";
      const pageDescription = "${pageDescription}";
      const pageUrl = "${pageUrl}";

      // 海报按钮悬停效果
      document.getElementById('share-btn').addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-50%) translateX(-2px)';
        this.style.boxShadow = '0 5px 16px rgba(102, 126, 234, 0.6)';
        this.style.opacity = '1';
      });
      
      document.getElementById('share-btn').addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(-50%) translateX(0)';
        this.style.boxShadow = '0 3px 12px rgba(102, 126, 234, 0.4)';
        this.style.opacity = '0.9';
      });

      // 打开海报页面
      function openSharePoster() {
        const url = \`/api/poster/\${pageId}\`;
        
        const posterWindow = window.open(url, 'sharePoster',
          'width=800,height=900,scrollbars=yes,resizable=yes'
        );
        
        if (posterWindow) {
          posterWindow.focus();
        } else {
          // 弹窗被阻止时的处理
          alert('请允许弹窗或直接访问海报页面：' + url);
        }
      }

      // 滚动时自动调整按钮透明度，避免遮挡内容
      let scrollTimeout;
      window.addEventListener('scroll', function() {
        const btn = document.getElementById('share-btn');
        if (btn) {
          btn.style.opacity = '0.5';
          
          clearTimeout(scrollTimeout);
          scrollTimeout = setTimeout(() => {
            btn.style.opacity = '0.9';
          }, 150);
        }
      });

      // 检测移动端并调整样式
      function adjustForMobile() {
        const btn = document.getElementById('share-btn');
        if (window.innerWidth <= 768 && btn) {
          // 移动端调整：更小尺寸，更透明
          btn.style.width = '32px';
          btn.style.height = '70px';
          btn.style.padding = '6px 4px';
          btn.style.opacity = '0.8';
          
          // 调整图标和文字尺寸
          const spans = btn.querySelectorAll('span');
          if (spans.length > 0) {
            spans[0].style.fontSize = '12px'; // 图标
            for (let i = 1; i < spans.length; i++) {
              spans[i].style.fontSize = '9px'; // 文字
            }
          }
        }
      }
      
      // 页面加载和窗口调整时检测
      adjustForMobile();
      window.addEventListener('resize', adjustForMobile);

      // 调试信息
      console.log('海报分享功能已加载');
      console.log('页面ID:', pageId);
      console.log('页面标题:', pageTitle);
      console.log('页面URL:', pageUrl);
    </script>
  `;
}

module.exports = {
  getWechatShareImage,
  generateWechatMetaTags,
  generateWechatShareButton
} 