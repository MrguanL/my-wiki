const QRCode = require('qrcode')

/**
 * 生成二维码数据URL
 * @param {String} url - 要编码的URL
 * @returns {String} - 二维码的data URL
 */
async function generateQRCodeDataURL(url) {
  try {
    return await QRCode.toDataURL(url, {
      width: 200,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    })
  } catch (error) {
    console.warn('二维码生成失败:', error)
    return null
  }
}

/**
 * 生成海报页面HTML（调试增强版）
 * @param {Object} page - 页面对象
 * @param {Object} config - 站点配置
 * @param {String} url - 页面URL
 * @returns {String} - 海报HTML
 */
async function generatePosterHTML(page, config, url) {
  const qrCodeDataURL = await generateQRCodeDataURL(url)
  
  const title = page.title || '知识分享'
  const description = page.description || config.description || '来自恒源知享的知识分享'
  const siteName = config.title || '恒源知享'
  
  return `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>分享海报 - ${title}</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 20px;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      margin: 0; /* 重要：去除默认边距 */
      box-sizing: border-box;
    }
    

    
    .poster-container {
      width: 400px;
      min-height: 600px;
      max-width: 400px; /* 防止变形 */
      background: white;
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 25px 50px rgba(0,0,0,0.3);
      position: relative;
      display: flex;
      flex-direction: column;
      margin: 0 auto; /* 居中显示 */
      box-sizing: border-box; /* 确保尺寸计算正确 */
    }
    
    .poster-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 30px 25px;
      text-align: center;
      color: white;
      position: relative;
      overflow: hidden;
    }
    
    .poster-header::before {
      content: '';
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="2" fill="rgba(255,255,255,0.1)"/><circle cx="80" cy="30" r="1.5" fill="rgba(255,255,255,0.1)"/><circle cx="30" cy="80" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="70" cy="70" r="2" fill="rgba(255,255,255,0.1)"/></svg>');
      animation: float 20s linear infinite;
      pointer-events: none;
    }
    
    @keyframes float {
      0% { transform: translateX(-50%) translateY(-50%) rotate(0deg); }
      100% { transform: translateX(-50%) translateY(-50%) rotate(360deg); }
    }
    
    .logo {
      width: 80px;
      height: 80px;
      background: rgba(255,255,255,0.15);
      border-radius: 20px;
      margin: 0 auto 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 32px;
      backdrop-filter: blur(10px);
      border: 2px solid rgba(255,255,255,0.2);
      position: relative;
      z-index: 2;
    }
    
    .site-name {
      font-size: 28px;
      font-weight: 700;
      margin-bottom: 8px;
      position: relative;
      z-index: 2;
    }
    
    .subtitle {
      font-size: 16px;
      opacity: 0.9;
      position: relative;
      z-index: 2;
    }
    
    .poster-content {
      flex: 1;
      padding: 35px 25px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    
    .content-title {
      font-size: 24px;
      font-weight: 700;
      line-height: 1.4;
      margin-bottom: 20px;
      color: #2c3e50;
      text-align: center;
    }
    
    .content-description {
      font-size: 16px;
      line-height: 1.6;
      color: #5a6c7d;
      margin-bottom: 30px;
      text-align: center;
      max-height: 120px;
      overflow: hidden;
      display: -webkit-box;
      -webkit-line-clamp: 5;
      -webkit-box-orient: vertical;
    }
    
    .poster-footer {
      background: #f8f9fa;
      padding: 25px;
      text-align: center;
      border-top: 1px solid #e9ecef;
    }
    
    .qr-section {
      margin-bottom: 20px;
    }
    
    .qr-code {
      width: 120px;
      height: 120px;
      background: white;
      border-radius: 15px;
      padding: 10px;
      margin: 0 auto 15px;
      display: inline-block;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .qr-code img {
      width: 100%;
      height: 100%;
      border-radius: 8px;
    }
    
    .qr-text {
      font-size: 14px;
      color: #6c757d;
      margin-bottom: 15px;
    }
    
    .page-link {
      display: inline-block;
      background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
      color: white;
      text-decoration: none;
      padding: 12px;
      border-radius: 8px;
      font-family: monospace;
      font-size: 11px;
      word-break: break-all;
      line-height: 1.4;
      box-shadow: 0 4px 12px rgba(79, 172, 254, 0.3);
      transition: all 0.3s ease;
      margin: 15px 0;
      max-width: 100%;
      text-align: left;
    }
    
    .page-link:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(79, 172, 254, 0.4);
    }
    
    .brand-footer {
      color: #6c757d;
      font-size: 14px;
      line-height: 1.6;
    }
    
    .brand-footer strong {
      color: #495057;
    }
    
    .controls {
      display: flex;
      gap: 15px;
      margin-top: 20px;
      flex-wrap: wrap;
      justify-content: center;
    }
    
    .btn {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 25px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(118, 75, 162, 0.3);
      min-width: 120px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }
    
    .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(118, 75, 162, 0.4);
    }
    
    .btn:active {
      transform: translateY(0);
    }
    
    .btn-copy {
      background: linear-gradient(135deg, #ff6b6b 0%, #ffa726 100%);
      box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);
    }
    
    .btn-copy:hover {
      box-shadow: 0 6px 20px rgba(255, 107, 107, 0.4);
    }
    
    .btn-text {
      background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
      box-shadow: 0 4px 15px rgba(79, 172, 254, 0.3);
    }
    
    .btn-text:hover {
      box-shadow: 0 6px 20px rgba(79, 172, 254, 0.4);
    }
    
    .btn-close {
      background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
      box-shadow: 0 4px 15px rgba(108, 117, 125, 0.3);
    }
    
    .btn-close:hover {
      box-shadow: 0 6px 20px rgba(108, 117, 125, 0.4);
    }
    
    .toast {
      position: fixed;
      top: 20px;
      right: 20px;
      background: #28a745;
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 500;
      z-index: 10000;
      opacity: 0;
      transform: translateX(100%);
      transition: all 0.3s ease;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .toast.show {
      opacity: 1;
      transform: translateX(0);
    }
    
    .toast.error {
      background: #dc3545;
    }
    
    .progress-overlay {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.3);
      z-index: 20000;
      min-width: 300px;
      text-align: center;
    }
    
    .progress-bar {
      width: 100%;
      height: 8px;
      background: #f0f0f0;
      border-radius: 4px;
      overflow: hidden;
      margin: 15px 0 10px 0;
    }
    
    .progress-fill {
      height: 100%;
      background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%);
      transition: width 0.3s ease;
      border-radius: 4px;
    }
    
    @media (max-width: 480px) {
      .poster-container {
        width: 90%;
        max-width: 350px;
        min-width: 300px;
        margin: 0 auto;
        box-sizing: border-box;
      }
    }
      
      .content-title {
        font-size: 20px;
      }
      
      .content-description {
        font-size: 14px;
      }
      
      .controls {
        flex-direction: column;
        align-items: center;
      }
      
      .btn {
        width: 100%;
        max-width: 200px;
      }
    }
    
    @media print {
      body {
        background: white;
        padding: 0;
      }
      
      .controls {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div class="poster-container" id="poster">
    <div class="poster-header">
      <div class="logo">📚</div>
      <div class="site-name">${siteName}</div>
      <div class="subtitle">知识分享平台</div>
    </div>
    
    <div class="poster-content">
      <h1 class="content-title">${title}</h1>
      <p class="content-description">${description}</p>
    </div>
    
    <div class="poster-footer">
      <div class="qr-section">
        <div class="qr-code">
          ${qrCodeDataURL ? `<img src="${qrCodeDataURL}" alt="扫码查看详情" />` : '<div style="text-align:center;font-size:12px;color:#666;line-height:100px;">二维码</div>'}
        </div>
        <div class="qr-text">扫码查看详情，或通过地址前往观看</div>
        
        <div style="
          background: #f8f9fa; 
          border: 1px solid #e9ecef; 
          border-radius: 8px; 
          padding: 12px; 
          margin: 15px 0; 
          font-family: monospace; 
          font-size: 11px; 
          color: #495057; 
          word-break: break-all; 
          line-height: 1.4;
          text-align: left;
        ">${url}</div>
      </div>
      
      <div class="brand-footer">
        <strong>${siteName}</strong><br>
        分享知识 · 传递价值<br>
        发现更多精彩内容
      </div>
    </div>
  </div>
  
  <div class="controls">
    <button class="btn btn-copy" onclick="copyImageToClipboard()">
      📋 复制图片
    </button>
    <button class="btn btn-text" onclick="copyShareText()">
      📝 复制文案
    </button>
    <button class="btn btn-close" onclick="window.close()">
      ❌ 关闭
    </button>
  </div>
  
  <div id="toast" class="toast"></div>
  
  <script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js" 
          crossorigin="anonymous" 
          onerror="handleCDNFailure()"></script>
  
  <!-- 备用CDN -->
  <script>
    let html2canvasLoaded = false;
    let html2canvasLoadAttempts = 0;
    const maxLoadAttempts = 3;
    
    // 检查html2canvas是否加载成功
    function checkHtml2Canvas() {
      if (typeof html2canvas !== 'undefined') {
        html2canvasLoaded = true;
        console.log('✅ html2canvas 加载成功');
        return true;
      }
      return false;
    }
    
    // 处理CDN加载失败
    function handleCDNFailure() {
      html2canvasLoadAttempts++;
      console.warn('❌ CDN加载失败，尝试次数:', html2canvasLoadAttempts);
      
      if (html2canvasLoadAttempts < maxLoadAttempts) {
        // 尝试备用CDN
        const backupCDNs = [
          'https://unpkg.com/html2canvas@1.4.1/dist/html2canvas.min.js',
          'https://cdn.bootcdn.net/ajax/libs/html2canvas/1.4.1/html2canvas.min.js',
          'https://lib.baomitu.com/html2canvas/1.4.1/html2canvas.min.js'
        ];
        
        const script = document.createElement('script');
        script.src = backupCDNs[html2canvasLoadAttempts - 1];
        script.crossOrigin = 'anonymous';
        script.onerror = handleCDNFailure;
        script.onload = function() {
          console.log('✅ 备用CDN加载成功:', script.src);
          html2canvasLoaded = true;
        };
        document.head.appendChild(script);
      } else {
        console.error('❌ 所有CDN都加载失败');
        showToast('⚠️ 图片生成功能暂不可用，请复制文案分享', true);
        
        const copyBtn = document.querySelector('.btn-copy');
        if (copyBtn) {
          copyBtn.style.display = 'none';
        }
      }
    }
    
    // 等待加载完成
    setTimeout(checkHtml2Canvas, 100);
  </script>
  
  <script>
    let posterCanvas = null;
    let isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    let isHTTPS = location.protocol === 'https:';
    let isWeChat = /MicroMessenger/i.test(navigator.userAgent);
    let isChrome = /Chrome/i.test(navigator.userAgent) && !/Edge|Edg/i.test(navigator.userAgent);
    let isSafari = /Safari/i.test(navigator.userAgent) && !/Chrome|Chromium/i.test(navigator.userAgent);
    
    // 调试信息输出
    console.log('🚀 海报页面初始化');
    console.log('📱 移动端检测:', isMobile);
    console.log('🔒 HTTPS环境:', isHTTPS);
    console.log('💬 微信环境:', isWeChat);
    console.log('🌐 Chrome浏览器:', isChrome);
    console.log('🍎 Safari浏览器:', isSafari);
    console.log('🌐 用户代理:', navigator.userAgent);
    
    // 浏览器特定警告
    if (isWeChat) {
      console.log('💬 微信环境专项检测:');
      console.log('💬 - 将使用降级渲染模式');
      console.log('💬 - 剪贴板功能可能受限');
      console.log('💬 - 图片分享将自动下载到收藏');
    }
    
    if (isChrome) {
      console.log('🌐 Chrome浏览器专项检测:');
      console.log('🌐 - 使用标准渲染模式');
      console.log('🌐 - CORS策略可能影响跨域资源');
    }
    
    // 手机端专用调试
    if (isMobile) {
      console.log('📱 === 移动端调试信息 ===');
      console.log('📱 屏幕尺寸:', window.screen.width + 'x' + window.screen.height);
      console.log('📱 视窗尺寸:', window.innerWidth + 'x' + window.innerHeight);
      console.log('📱 设备像素比:', window.devicePixelRatio || 1);
      console.log('📱 设备内存:', navigator.deviceMemory ? navigator.deviceMemory + 'GB' : '未知');
      console.log('📱 硬件并发:', navigator.hardwareConcurrency || '未知');
      console.log('📱 连接类型:', navigator.connection ? navigator.connection.effectiveType : '未知');
      console.log('📱 是否低端设备:', isLowEndDevice());
      console.log('📱 === 调试信息结束 ===');
      
      // 移动端性能警告
      if (isLowEndDevice()) {
        showToast('📱 检测到低端设备，将使用低质量模式', false);
      }
    }
    
    // 检测是否为低端设备
    function isLowEndDevice() {
      // 多个维度判断低端设备
      const memory = navigator.deviceMemory;
      const cores = navigator.hardwareConcurrency;
      const pixelRatio = window.devicePixelRatio || 1;
      
      // 内存小于2GB
      if (memory && memory < 2) return true;
      
      // CPU核心少于4个
      if (cores && cores < 4) return true;
      
      // 低分辨率设备
      if (window.screen.width * pixelRatio < 1080) return true;
      
      // 旧版iOS/Android
      const isOldAndroid = /Android [1-6]\./.test(navigator.userAgent);
      const isOldIOS = /OS [1-9]_/.test(navigator.userAgent);
      
      return isOldAndroid || isOldIOS;
    }
    
    // 等待html2canvas库加载
    function waitForHtml2Canvas() {
      return new Promise(function(resolve, reject) {
        let attempts = 0;
        const maxAttempts = 50; // 5秒超时
        
        function check() {
          attempts++;
          
          if (typeof html2canvas !== 'undefined') {
            console.log('✅ html2canvas库准备就绪');
            resolve(true);
          } else if (attempts >= maxAttempts) {
            console.error('❌ html2canvas库加载超时');
            reject(new Error('html2canvas库加载超时'));
          } else {
            setTimeout(check, 100);
          }
        }
        
        check();
      });
    }
    
    function showProgress(progress, message) {
      console.log('📊 进度更新:', progress + '% - ' + message);
      
      let progressOverlay = document.getElementById('progress-overlay');
      if (!progressOverlay) {
        progressOverlay = document.createElement('div');
        progressOverlay.id = 'progress-overlay';
        progressOverlay.className = 'progress-overlay';
        document.body.appendChild(progressOverlay);
        console.log('📊 创建进度条显示');
      }
      
      const debugInfo = isWeChat ? '微信环境调试' : (isChrome ? 'Chrome调试' : (isSafari ? 'Safari调试' : '未知浏览器'));
      
      progressOverlay.innerHTML = '<div>' + message + '</div>' +
        '<div class="progress-bar">' +
          '<div class="progress-fill" style="width: ' + progress + '%"></div>' +
        '</div>' +
        '<div style="font-size: 12px; color: #666;">' + progress + '%</div>' +
        (isMobile ? '<div style="font-size: 10px; color: #999; margin-top: 10px;">' + debugInfo + '</div>' : '');
      
      // 移动端进度卡顿检测
      if (isMobile && progress > 0) {
        setTimeout(function() {
          const currentProgress = progressOverlay.querySelector('.progress-fill').style.width;
          if (currentProgress === progress + '%') {
            console.warn('⚠️ 进度条可能卡住在 ' + progress + '%');
          }
        }, 3000);
      }
    }
    
    function hideProgress() {
      console.log('📊 隐藏进度条');
      const progressOverlay = document.getElementById('progress-overlay');
      if (progressOverlay) {
        progressOverlay.remove();
      }
    }
    
    function showToast(message, isError) {
      console.log('💬 显示提示:', message, isError ? '(错误)' : '(普通)');
      const toast = document.getElementById('toast');
      toast.textContent = message;
      toast.className = 'toast' + (isError ? ' error' : '') + ' show';
      
      setTimeout(function() {
        toast.classList.remove('show');
      }, 3000);
    }
    

    
    // 安全模式生成（降级版本）
    async function generatePosterCanvasSafeMode() {
      console.log('🛡️ 启用安全模式生成');
      
      const { poster, controls } = prepareForRender();
      
      try {
        showProgress(30, '安全模式：准备元素...');
        
        await new Promise(function(resolve) {
          setTimeout(resolve, 500);
        });
        
        showProgress(60, '安全模式：开始渲染...');
        
        const safeOptions = {
          width: poster.offsetWidth,
          height: poster.offsetHeight,
          scale: 1,
          backgroundColor: 'white',
          useCORS: false,
          allowTaint: true,
          logging: false,
          removeContainer: true
        };
        
        console.log('🛡️ 安全模式配置:', safeOptions);
        showProgress(80, '安全模式：渲染中...');
        
        const canvas = await html2canvas(poster, safeOptions);
        
        showProgress(100, '安全模式：完成！');
        console.log('🛡️ 安全模式生成成功:', canvas.width + 'x' + canvas.height);
        
        return canvas;
        
      } catch (error) {
        throw error;
      } finally {
        cleanupAfterRender(controls);
      }
    }
    

    
    // 简单的渲染准备
    function prepareForRender() {
      const poster = document.getElementById('poster');
      const controls = document.querySelector('.controls');
      
      // 隐藏控制按钮
      if (controls) {
        controls.style.display = 'none';
      }
      
      // 清除动画效果
      poster.style.transform = 'none';
      poster.style.transition = 'none';
      poster.style.opacity = '1';
      
      return { poster, controls };
    }
    
    function cleanupAfterRender(controls) {
      if (controls) {
        controls.style.display = 'flex';
      }
    }

    async function generatePosterCanvas() {
      if (posterCanvas) {
        console.log('♻️ 使用缓存的Canvas');
        return posterCanvas;
      }
      
      console.log('🚀 开始生成海报Canvas');
      
      try {
        // 等待html2canvas库加载
        showProgress(5, '等待组件加载...');
        await waitForHtml2Canvas();
        
        showProgress(10, '准备渲染环境...');
        
        console.log('✅ html2canvas 库已加载');
        
        const { poster, controls } = prepareForRender();
        
        if (!poster) {
          throw new Error('找不到海报元素');
        }
        
        console.log('📐 海报元素尺寸:', poster.offsetWidth + 'x' + poster.offsetHeight);
        
        showProgress(30, '等待元素稳定...');
        
        await new Promise(function(resolve) {
          setTimeout(resolve, 1000);
        });
        
        showProgress(50, '开始生成图片...');
        
        // 使用Safari成功的配置（适用所有浏览器）
        const options = {
          width: poster.offsetWidth,
          height: poster.offsetHeight,
          scale: 2,
          useCORS: true,
          allowTaint: false,
          logging: false,
          backgroundColor: null,
          removeContainer: true,
          imageTimeout: 15000
        };
        
        console.log('📐 统一渲染配置:', options);
        showProgress(80, '正在渲染海报...');
        
        const canvas = await html2canvas(poster, options);
        
        posterCanvas = canvas;
        showProgress(100, '生成完成！');
        
        console.log('🎉 Canvas生成成功:', canvas.width + 'x' + canvas.height);
        return canvas;
        
      } catch (error) {
        console.error('❌ Canvas生成失败:', error);
        
        throw error;
      } finally {
        hideProgress();
        
        // 清理渲染状态
        const controls = document.querySelector('.controls');
        cleanupAfterRender(controls);
      }
    }
    
    async function copyImageToClipboard() {
      try {
        console.log('🖼️ 开始复制图片流程');
        
        // 清除缓存，强制重新生成高质量版本
        posterCanvas = null;
        console.log('🗑️ 已清除缓存，将重新生成');
        
        showToast('正在生成图片...');
        console.log('🎯 使用统一配置生成高质量图片');
        
        const canvas = await generatePosterCanvas();
        
        console.log('🎯 Canvas生成成功，开始复制处理');
        
        if (isMobile) {
          console.log('📱 使用移动端处理流程');
          handleMobileCopy(canvas);
        } else {
          console.log('🖥️ 使用桌面端处理流程');
          handleDesktopCopy(canvas);
        }
        
      } catch (error) {
        console.error('❌ 生成图片失败:', error);
        hideProgress();
        
        // 简化错误处理，自动重试安全模式
        console.error('图片生成失败，尝试安全模式:', error);
        
        try {
          showToast('⚠️ 尝试兼容模式...');
          const canvas = await generatePosterCanvasSafeMode();
          
          if (isMobile) {
            handleMobileCopy(canvas);
          } else {
            handleDesktopCopy(canvas);
          }
          return;
        } catch (safeError) {
          console.error('安全模式也失败:', safeError);
          showToast('❌ 图片生成失败，请复制文案分享', true);
        }

      }
    }
    
    function handleDesktopCopy(canvas) {
      canvas.toBlob(async function(blob) {
        try {
          if (isHTTPS && navigator.clipboard && window.ClipboardItem) {
            try {
              const item = new ClipboardItem({ 'image/png': blob });
              await navigator.clipboard.write([item]);
              showToast('✅ 图片已复制到剪贴板！');
              return;
            } catch (clipboardError) {
              console.warn('剪贴板API失败，使用降级方案:', clipboardError);
            }
          }
          
          showImageInNewWindow(blob);
        } catch (error) {
          console.error('复制失败:', error);
          showImageInNewWindow(blob);
        }
      }, 'image/png', 0.9);
    }
    
    function handleMobileCopy(canvas) {
      canvas.toBlob(async function(blob) {
        try {
          const isWeChat = /MicroMessenger/i.test(navigator.userAgent);
          
          if (isWeChat) {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = '分享海报.png';
            a.style.display = 'none';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            showToast('📱 图片已保存，请在微信【我】→【收藏】中查看');
            return;
          }
          
          if (navigator.share && navigator.canShare) {
            const file = new File([blob], '分享海报.png', { type: 'image/png' });
            if (navigator.canShare({ files: [file] })) {
              await navigator.share({
                title: '分享海报',
                text: '来自恒源知享的知识分享',
                files: [file]
              });
              showToast('✅ 分享成功！');
              return;
            }
          }
          
          if (isHTTPS && navigator.clipboard && window.ClipboardItem) {
            try {
              const item = new ClipboardItem({ 'image/png': blob });
              await navigator.clipboard.write([item]);
              showToast('✅ 图片已复制到剪贴板！');
              return;
            } catch (clipboardError) {
              console.warn('移动端剪贴板API失败:', clipboardError);
            }
          }
          
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = '分享海报.png';
          a.style.display = 'none';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
          showToast('📱 图片已下载，请在相册中查看');
        } catch (error) {
          console.error('移动端处理失败:', error);
          showImageInNewWindow(blob);
          showToast('📱 请长按图片保存到相册');
        }
      }, 'image/png', 0.9);
    }
    
    function showImageInNewWindow(blob) {
      const url = URL.createObjectURL(blob);
      const img = document.createElement('img');
      img.src = url;
      img.style.cssText = 'max-width: 100%; height: auto; display: block; margin: 0 auto;';
      
      const newWindow = window.open('', '_blank');
      if (newWindow) {
        newWindow.document.head.innerHTML = '<title>分享海报</title><meta name="viewport" content="width=device-width, initial-scale=1">';
        newWindow.document.body.innerHTML = 
          '<div style="text-align: center; padding: 20px; font-family: Arial, sans-serif;">' +
            '<h3 style="margin-bottom: 20px;">🖼️ 分享海报</h3>' +
            '<p style="color: #666; margin-bottom: 20px;">' +
              (isMobile ? '长按图片保存到相册' : '右键点击图片选择"复制图片"或"图片另存为"') +
            '</p>' +
            img.outerHTML +
          '</div>';
        showToast('📋 请在新窗口中' + (isMobile ? '长按保存' : '右键复制') + '图片');
      } else {
        showToast('❌ 请允许弹窗后重试', true);
      }
    }
    
    async function copyShareText() {
      const title = document.querySelector('.content-title').textContent;
      const description = document.querySelector('.content-description').textContent;
      
      const text = '📚 【' + title + '】\\n\\n' + description + '\\n\\n🔗 查看详情：' + 
                   (window.opener ? window.opener.location.href : '${url}') + 
                   '\\n\\n来自 ${siteName} 的知识分享';
      
      try {
        const isWeChat = /MicroMessenger/i.test(navigator.userAgent);
        
        if (isWeChat) {
          showTextModal(text, '微信内请手动复制以下文案：');
          return;
        }
        
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(text);
          showToast('✅ 分享文案已复制到剪贴板！');
        } else {
          throw new Error('剪贴板API不可用');
        }
      } catch (error) {
        console.warn('现代剪贴板API失败，使用降级方案:', error);
        
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        
        if (isMobile) {
          textarea.style.fontSize = '16px';
          textarea.readOnly = false;
        }
        
        textarea.select();
        textarea.setSelectionRange(0, textarea.value.length);
        
        try {
          const success = document.execCommand('copy');
          if (success) {
            showToast('✅ 分享文案已复制到剪贴板！');
          } else {
            throw new Error('execCommand失败');
          }
        } catch (execError) {
          console.error('所有复制方法都失败:', execError);
          showToast('❌ 复制失败，显示文案供手动复制', true);
          showTextModal(text, '请手动复制以下文案：');
        } finally {
          document.body.removeChild(textarea);
        }
      }
    }
    
    function showTextModal(text, title) {
      const modal = document.createElement('div');
      modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);display:flex;justify-content:center;align-items:center;z-index:10000;padding:20px;box-sizing:border-box;';
      modal.innerHTML = 
        '<div style="background:white;padding:20px;border-radius:15px;max-width:100%;max-height:90%;overflow:auto;box-shadow:0 10px 30px rgba(0,0,0,0.3);">' +
          '<h3 style="margin:0 0 15px 0;color:#333;font-size:18px;">' + title + '</h3>' +
          '<textarea readonly style="width:100%;height:200px;margin:10px 0;padding:10px;border:1px solid #ddd;border-radius:8px;font-size:14px;line-height:1.5;resize:none;font-family:inherit;" onclick="this.select()">' + text + '</textarea>' +
          '<div style="text-align:center;margin-top:15px;">' +
            '<button onclick="this.parentElement.parentElement.parentElement.remove()" style="padding:12px 24px;background:#007bff;color:white;border:none;border-radius:8px;font-size:16px;cursor:pointer;">关闭</button>' +
          '</div>' +
          '<p style="margin:10px 0 0 0;font-size:12px;color:#666;text-align:center;">' +
            (isMobile ? '点击文本框选中内容，然后手动复制' : '点击文本框即可全选内容') +
          '</p>' +
        '</div>';
      
      modal.addEventListener('click', function(e) {
        if (e.target === modal) {
          modal.remove();
        }
      });
      
      document.body.appendChild(modal);
      
      setTimeout(function() {
        const textarea = modal.querySelector('textarea');
        textarea.focus();
        textarea.select();
      }, 100);
    }
    
    document.addEventListener('DOMContentLoaded', function() {
      const poster = document.querySelector('.poster-container');
      poster.style.opacity = '0';
      poster.style.transform = 'translateY(30px) scale(0.95)';
      poster.style.transition = 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
      
      setTimeout(function() {
        poster.style.opacity = '1';
        poster.style.transform = 'translateY(0) scale(1)';
      }, 200);
      
      if (isMobile) {
        console.log('移动端模式：优化了图片分享体验');
      }
      
      if (isHTTPS) {
        if (!navigator.clipboard) {
          console.warn('HTTPS环境下剪贴板API不可用');
        }
        
        if (!window.isSecureContext) {
          console.warn('不是安全上下文，某些功能可能受限');
        }
        
        console.log('HTTPS环境检查完成');
      }
    });
    
    // 不再预生成缓存，确保每次都使用最新配置
    console.log('🎯 页面加载完成，已禁用预缓存以确保使用最新配置');
  </script>
</body>
</html>
  `
}

module.exports = {
  generatePosterHTML,
  generateQRCodeDataURL
} 