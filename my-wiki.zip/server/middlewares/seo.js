const _ = require('lodash')

/* global WIKI */

/**
 * SEO Middleware
 *
 * @param      {Express Request}   req     Express request object
 * @param      {Express Response}  res     Express response object
 * @param      {Function}          next    next callback function
 * @return     {any}               void
 */
module.exports = function (req, res, next) {
  if (req.path.length > 1 && _.endsWith(req.path, '/')) {
    let query = req.url.slice(req.path.length) || ''
    res.redirect(301, req.path.slice(0, -1) + query)
  } else {
    // 生成SEO友好的URL，微信分享使用标准端口
    let seoUrl
    const host = req.get('host')
    
    // 如果是外网域名，使用标准端口
    if (host && (host.includes('hyzx.heengy.cn') || host.includes('yourdomain.com'))) {
      const protocol = req.secure || req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http'
      const cleanHost = host.split(':')[0] // 移除端口号
      seoUrl = `${protocol}://${cleanHost}${req.path}`
    } else {
      // 本地开发环境保持原有逻辑
      seoUrl = `${WIKI.config.host}${req.path}`
    }
    
    _.set(res.locals, 'pageMeta.url', seoUrl)
    return next()
  }
}
