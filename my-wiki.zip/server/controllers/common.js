const express = require('express')
const router = express.Router()
const pageHelper = require('../helpers/page')
const wechatHelper = require('../helpers/wechat-simple')
const _ = require('lodash')
const CleanCSS = require('clean-css')
const moment = require('moment')
const qs = require('querystring')

/* global WIKI */

const tmplCreateRegex = /^[0-9]+(,[0-9]+)?$/

/**
 * Robots.txt
 */
router.get('/robots.txt', (req, res, next) => {
  res.type('text/plain')
  if (_.includes(WIKI.config.seo.robots, 'noindex')) {
    res.send('User-agent: *\nDisallow: /')
  } else {
    res.status(200).end()
  }
})

/**
 * Health Endpoint
 */
router.get('/healthz', (req, res, next) => {
  if (WIKI.models.knex.client.pool.numFree() < 1 && WIKI.models.knex.client.pool.numUsed() < 1) {
    res.status(503).json({ ok: false }).end()
  } else {
    res.status(200).json({ ok: true }).end()
  }
})

/**
 * Administration
 */
router.get(['/a', '/a/*'], (req, res, next) => {
  if (!WIKI.auth.checkAccess(req.user, [
    'manage:system',
    'write:users',
    'manage:users',
    'write:groups',
    'manage:groups',
    'manage:navigation',
    'manage:theme',
    'manage:api'
  ])) {
    _.set(res.locals, 'pageMeta.title', 'Unauthorized')
    return res.status(403).render('unauthorized', { action: 'view' })
  }

  _.set(res.locals, 'pageMeta.title', 'Admin')
  res.render('admin')
})

/**
 * Download Page / Version
 */
router.get(['/d', '/d/*'], async (req, res, next) => {
  const pageArgs = pageHelper.parsePath(req.path, { stripExt: true })

  const versionId = (req.query.v) ? _.toSafeInteger(req.query.v) : 0

  const page = await WIKI.models.pages.getPageFromDb({
    path: pageArgs.path,
    locale: pageArgs.locale,
    userId: req.user.id,
    isPrivate: false
  })

  pageArgs.tags = _.get(page, 'tags', [])

  if (versionId > 0) {
    if (!WIKI.auth.checkAccess(req.user, ['read:history'], pageArgs)) {
      _.set(res.locals, 'pageMeta.title', 'Unauthorized')
      return res.render('unauthorized', { action: 'downloadVersion' })
    }
  } else {
    if (!WIKI.auth.checkAccess(req.user, ['read:source'], pageArgs)) {
      _.set(res.locals, 'pageMeta.title', 'Unauthorized')
      return res.render('unauthorized', { action: 'download' })
    }
  }

  if (page) {
    const fileName = _.last(page.path.split('/')) + '.' + pageHelper.getFileExtension(page.contentType)
    res.attachment(fileName)
    if (versionId > 0) {
      const pageVersion = await WIKI.models.pageHistory.getVersion({ pageId: page.id, versionId })
      res.send(pageHelper.injectPageMetadata(pageVersion))
    } else {
      res.send(pageHelper.injectPageMetadata(page))
    }
  } else {
    res.status(404).end()
  }
})

/**
 * Create/Edit document
 */
router.get(['/e', '/e/*'], async (req, res, next) => {
  const pageArgs = pageHelper.parsePath(req.path, { stripExt: true })

  if (WIKI.config.lang.namespacing && !pageArgs.explicitLocale) {
    return res.redirect(`/e/${pageArgs.locale}/${pageArgs.path}`)
  }

  req.i18n.changeLanguage(pageArgs.locale)

  // -> Set Editor Lang
  _.set(res, 'locals.siteConfig.lang', pageArgs.locale)
  _.set(res, 'locals.siteConfig.rtl', req.i18n.dir() === 'rtl')

  // -> Check for reserved path
  if (pageHelper.isReservedPath(pageArgs.path)) {
    return next(new Error('Cannot create this page because it starts with a system reserved path.'))
  }

  // -> Get page data from DB
  let page = await WIKI.models.pages.getPageFromDb({
    path: pageArgs.path,
    locale: pageArgs.locale,
    userId: req.user.id,
    isPrivate: false
  })

  pageArgs.tags = _.get(page, 'tags', [])

  // -> Effective Permissions
  const effectivePermissions = WIKI.auth.getEffectivePermissions(req, pageArgs)

  const injectCode = {
    css: WIKI.config.theming.injectCSS,
    head: WIKI.config.theming.injectHead,
    body: WIKI.config.theming.injectBody
  }

  if (page) {
    // -> EDIT MODE
    if (!(effectivePermissions.pages.write || effectivePermissions.pages.manage)) {
      _.set(res.locals, 'pageMeta.title', 'Unauthorized')
      return res.render('unauthorized', { action: 'edit' })
    }

    // -> Get page tags
    await page.$relatedQuery('tags')
    page.tags = _.map(page.tags, 'tag')

    // Handle missing extra field
    page.extra = page.extra || { css: '', js: '' }

    // -> Beautify Script CSS
    if (!_.isEmpty(page.extra.css)) {
      page.extra.css = new CleanCSS({ format: 'beautify' }).minify(page.extra.css).styles
    }

    _.set(res.locals, 'pageMeta.title', `Edit ${page.title}`)
    // 确保描述不为空，微信分享需要
    const description = page.description || WIKI.config.description || `来自${WIKI.config.title || '恒源知享'}的知识分享`
    _.set(res.locals, 'pageMeta.description', description)
    page.mode = 'update'
    page.isPublished = (page.isPublished === true || page.isPublished === 1) ? 'true' : 'false'
    page.content = Buffer.from(page.content).toString('base64')
  } else {
    // -> CREATE MODE
    if (!effectivePermissions.pages.write) {
      _.set(res.locals, 'pageMeta.title', 'Unauthorized')
      return res.render('unauthorized', { action: 'create' })
    }

    _.set(res.locals, 'pageMeta.title', `New Page`)
    page = {
      path: pageArgs.path,
      localeCode: pageArgs.locale,
      editorKey: null,
      mode: 'create',
      content: null,
      title: null,
      description: null,
      updatedAt: new Date().toISOString(),
      extra: {
        css: '',
        js: ''
      }
    }

    // -> From Template
    if (req.query.from && tmplCreateRegex.test(req.query.from)) {
      let tmplPageId = 0
      let tmplVersionId = 0
      if (req.query.from.indexOf(',')) {
        const q = req.query.from.split(',')
        tmplPageId = _.toSafeInteger(q[0])
        tmplVersionId = _.toSafeInteger(q[1])
      } else {
        tmplPageId = _.toSafeInteger(req.query.from)
      }

      if (tmplVersionId > 0) {
        // -> From Page Version
        const pageVersion = await WIKI.models.pageHistory.getVersion({ pageId: tmplPageId, versionId: tmplVersionId })
        if (!pageVersion) {
          _.set(res.locals, 'pageMeta.title', 'Page Not Found')
          return res.status(404).render('notfound', { action: 'template' })
        }
        if (!WIKI.auth.checkAccess(req.user, ['read:history'], { path: pageVersion.path, locale: pageVersion.locale })) {
          _.set(res.locals, 'pageMeta.title', 'Unauthorized')
          return res.render('unauthorized', { action: 'sourceVersion' })
        }
        page.content = Buffer.from(pageVersion.content).toString('base64')
        page.editorKey = pageVersion.editor
        page.title = pageVersion.title
        page.description = pageVersion.description
      } else {
        // -> From Page Live
        const pageOriginal = await WIKI.models.pages.query().findById(tmplPageId)
        if (!pageOriginal) {
          _.set(res.locals, 'pageMeta.title', 'Page Not Found')
          return res.status(404).render('notfound', { action: 'template' })
        }
        if (!WIKI.auth.checkAccess(req.user, ['read:source'], { path: pageOriginal.path, locale: pageOriginal.locale })) {
          _.set(res.locals, 'pageMeta.title', 'Unauthorized')
          return res.render('unauthorized', { action: 'source' })
        }
        page.content = Buffer.from(pageOriginal.content).toString('base64')
        page.editorKey = pageOriginal.editorKey
        page.title = pageOriginal.title
        page.description = pageOriginal.description
      }
    }
  }

  res.render('editor', { page, injectCode, effectivePermissions })
})

/**
 * History
 */
router.get(['/h', '/h/*'], async (req, res, next) => {
  const pageArgs = pageHelper.parsePath(req.path, { stripExt: true })

  if (WIKI.config.lang.namespacing && !pageArgs.explicitLocale) {
    return res.redirect(`/h/${pageArgs.locale}/${pageArgs.path}`)
  }

  req.i18n.changeLanguage(pageArgs.locale)

  _.set(res, 'locals.siteConfig.lang', pageArgs.locale)
  _.set(res, 'locals.siteConfig.rtl', req.i18n.dir() === 'rtl')

  const page = await WIKI.models.pages.getPageFromDb({
    path: pageArgs.path,
    locale: pageArgs.locale,
    userId: req.user.id,
    isPrivate: false
  })

  if (!page) {
    _.set(res.locals, 'pageMeta.title', 'Page Not Found')
    return res.status(404).render('notfound', { action: 'history' })
  }

  pageArgs.tags = _.get(page, 'tags', [])

  const effectivePermissions = WIKI.auth.getEffectivePermissions(req, pageArgs)

  if (!effectivePermissions.history.read) {
    _.set(res.locals, 'pageMeta.title', 'Unauthorized')
    return res.render('unauthorized', { action: 'history' })
  }

  if (page) {
    _.set(res.locals, 'pageMeta.title', page.title)
    // 确保描述不为空，微信分享需要
    const description = page.description || WIKI.config.description || `来自${WIKI.config.title || '恒源知享'}的知识分享`
    _.set(res.locals, 'pageMeta.description', description)

    res.render('history', { page, effectivePermissions })
  } else {
    res.redirect(`/${pageArgs.path}`)
  }
})

/**
 * Page ID redirection
 */
router.get(['/i', '/i/:id'], async (req, res, next) => {
  const pageId = _.toSafeInteger(req.params.id)
  if (pageId <= 0) {
    return res.redirect('/')
  }

  const page = await WIKI.models.pages.query().column(['path', 'localeCode', 'isPrivate', 'privateNS']).findById(pageId)
  if (!page) {
    _.set(res.locals, 'pageMeta.title', 'Page Not Found')
    return res.status(404).render('notfound', { action: 'view' })
  }

  if (!WIKI.auth.checkAccess(req.user, ['read:pages'], {
    locale: page.localeCode,
    path: page.path,
    private: page.isPrivate,
    privateNS: page.privateNS,
    explicitLocale: false,
    tags: page.tags
  })) {
    _.set(res.locals, 'pageMeta.title', 'Unauthorized')
    return res.render('unauthorized', { action: 'view' })
  }

  if (WIKI.config.lang.namespacing) {
    return res.redirect(`/${page.localeCode}/${page.path}`)
  } else {
    return res.redirect(`/${page.path}`)
  }
})

/**
 * Profile
 */
router.get(['/p', '/p/*'], (req, res, next) => {
  if (!req.user || req.user.id < 1 || req.user.id === 2) {
    return res.render('unauthorized', { action: 'view' })
  }

  _.set(res.locals, 'pageMeta.title', 'User Profile')
  res.render('profile')
})

/**
 * Source
 */
router.get(['/s', '/s/*'], async (req, res, next) => {
  const pageArgs = pageHelper.parsePath(req.path, { stripExt: true })
  const versionId = (req.query.v) ? _.toSafeInteger(req.query.v) : 0

  const page = await WIKI.models.pages.getPageFromDb({
    path: pageArgs.path,
    locale: pageArgs.locale,
    userId: req.user.id,
    isPrivate: false
  })

  pageArgs.tags = _.get(page, 'tags', [])

  if (WIKI.config.lang.namespacing && !pageArgs.explicitLocale) {
    return res.redirect(`/s/${pageArgs.locale}/${pageArgs.path}`)
  }

  // -> Effective Permissions
  const effectivePermissions = WIKI.auth.getEffectivePermissions(req, pageArgs)

  _.set(res, 'locals.siteConfig.lang', pageArgs.locale)
  _.set(res, 'locals.siteConfig.rtl', req.i18n.dir() === 'rtl')

  if (versionId > 0) {
    if (!effectivePermissions.history.read) {
      _.set(res.locals, 'pageMeta.title', 'Unauthorized')
      return res.render('unauthorized', { action: 'sourceVersion' })
    }
  } else {
    if (!effectivePermissions.source.read) {
      _.set(res.locals, 'pageMeta.title', 'Unauthorized')
      return res.render('unauthorized', { action: 'source' })
    }
  }

  if (page) {
    if (versionId > 0) {
      const pageVersion = await WIKI.models.pageHistory.getVersion({ pageId: page.id, versionId })
      _.set(res.locals, 'pageMeta.title', pageVersion.title)
      // 确保描述不为空，微信分享需要
      const description = pageVersion.description || WIKI.config.description || `来自${WIKI.config.title || '恒源知享'}的知识分享`
      _.set(res.locals, 'pageMeta.description', description)
      res.render('source', {
        page: {
          ...page,
          ...pageVersion
        },
        effectivePermissions
      })
    } else {
      _.set(res.locals, 'pageMeta.title', page.title)
      // 确保描述不为空，微信分享需要
      const description = page.description || WIKI.config.description || `来自${WIKI.config.title || '恒源知享'}的知识分享`
      _.set(res.locals, 'pageMeta.description', description)

      res.render('source', { page, effectivePermissions })
    }
  } else {
    res.redirect(`/${pageArgs.path}`)
  }
})

/**
 * Tags
 */
router.get(['/t', '/t/*'], (req, res, next) => {
  _.set(res.locals, 'pageMeta.title', 'Tags')
  res.render('tags')
})

/**
 * User Avatar
 */
router.get('/_userav/:uid', async (req, res, next) => {
  if (!WIKI.auth.checkAccess(req.user, ['read:pages'])) {
    return res.sendStatus(403)
  }
  const av = await WIKI.models.users.getUserAvatarData(req.params.uid)
  if (av) {
    res.set('Content-Type', 'image/jpeg')
    res.send(av)
  }

  return res.sendStatus(404)
})

/**
 * View document / asset
 */
router.get('/*', async (req, res, next) => {
  const stripExt = _.some(WIKI.config.pageExtensions, ext => _.endsWith(req.path, `.${ext}`))
  const pageArgs = pageHelper.parsePath(req.path, { stripExt })
  const isPage = (stripExt || pageArgs.path.indexOf('.') === -1)

  if (isPage) {
    if (WIKI.config.lang.namespacing && !pageArgs.explicitLocale) {
      const query = !_.isEmpty(req.query) ? `?${qs.stringify(req.query)}` : ''
      return res.redirect(`/${pageArgs.locale}/${pageArgs.path}${query}`)
    }

    req.i18n.changeLanguage(pageArgs.locale)

    try {
      // -> Get Page from cache
      const page = await WIKI.models.pages.getPage({
        path: pageArgs.path,
        locale: pageArgs.locale,
        userId: req.user.id,
        isPrivate: false
      })
      pageArgs.tags = _.get(page, 'tags', [])

      // -> Effective Permissions
      const effectivePermissions = WIKI.auth.getEffectivePermissions(req, pageArgs)

      // -> Check User Access
      if (!effectivePermissions.pages.read) {
        if (req.user.id === 2) {
          res.cookie('loginRedirect', req.path, {
            maxAge: 15 * 60 * 1000
          })
        }
        if (pageArgs.path === 'home' && req.user.id === 2) {
          return res.redirect('/login')
        }
        _.set(res.locals, 'pageMeta.title', 'Unauthorized')
        return res.status(403).render('unauthorized', {
          action: 'view'
        })
      }

      _.set(res, 'locals.siteConfig.lang', pageArgs.locale)
      _.set(res, 'locals.siteConfig.rtl', req.i18n.dir() === 'rtl')

      if (page) {
        // -> Increment view count asynchronously and get current count
        if (page.id) {
          setImmediate(async () => {
            try {
              await WIKI.models.pages.incrementViewCount(page.id)
            } catch (err) {
              WIKI.logger.warn('Failed to increment view count:', err)
            }
          })
          
          // -> Get current view count from database for accurate display
          try {
            const currentPage = await WIKI.models.pages.query().select('viewCount').findById(page.id)
            if (currentPage) {
              page.viewCount = currentPage.viewCount || 0
            }
          } catch (err) {
            WIKI.logger.warn('Failed to get current view count:', err)
            page.viewCount = page.viewCount || 0
          }
        }

        _.set(res.locals, 'pageMeta.title', page.title)
        // 确保描述不为空，微信分享需要
        const description = page.description || WIKI.config.description || `来自${WIKI.config.title || '恒源知享'}的知识分享`
        _.set(res.locals, 'pageMeta.description', description)

        // -> Check Publishing State
        let pageIsPublished = page.isPublished
        if (pageIsPublished && !_.isEmpty(page.publishStartDate)) {
          pageIsPublished = moment(page.publishStartDate).isSameOrBefore()
        }
        if (pageIsPublished && !_.isEmpty(page.publishEndDate)) {
          pageIsPublished = moment(page.publishEndDate).isSameOrAfter()
        }
        if (!pageIsPublished && !effectivePermissions.pages.write) {
          _.set(res.locals, 'pageMeta.title', 'Unauthorized')
          return res.status(403).render('unauthorized', {
            action: 'view'
          })
        }

        // -> Build sidebar navigation
        let sdi = 1
        const sidebar = (await WIKI.models.navigation.getTree({ cache: true, locale: pageArgs.locale, groups: req.user.groups })).map(n => ({
          i: `sdi-${sdi++}`,
          k: n.kind,
          l: n.label,
          c: n.icon,
          y: n.targetType,
          t: n.target
        }))

        // -> Build theme code injection
        const injectCode = {
          css: WIKI.config.theming.injectCSS,
          head: WIKI.config.theming.injectHead,
          body: WIKI.config.theming.injectBody
        }

        // Handle missing extra field
        page.extra = page.extra || { css: '', js: '' }

        if (!_.isEmpty(page.extra.css)) {
          injectCode.css = `${injectCode.css}\n${page.extra.css}`
        }

        if (!_.isEmpty(page.extra.js)) {
          injectCode.body = `${injectCode.body}\n${page.extra.js}`
        }

                // 注入浏览次数显示脚本
        const viewCountScript = `
<script>
console.log('=== 浏览次数脚本开始执行 ===');
console.log('📊 当前页面浏览次数: ${page.viewCount || 0}');
console.log('📄 页面ID: ${page.id}');

(function() {
  let viewCountValue = ${page.viewCount || 0};
  let attempts = 0;
  const maxAttempts = 20;
  
  function addViewCountToCard() {
    attempts++;
    console.log('🔍 尝试添加浏览次数到页面，第' + attempts + '次');
    console.log('📊 要显示的浏览次数: ' + viewCountValue);
    
    // 检查是否已经添加过
    if (document.querySelector('.wiki-view-count-display')) {
      console.log('✅ 浏览次数已添加，跳过');
      return true;
    }
    
    // 查找合适的显示位置 - 桌面端和手机端兼容
    let targetContainer = null;
    let displayMode = 'inline'; // inline | floating
    
    // 检测是否为手机端
    const isMobile = window.innerWidth <= 768 || /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    console.log('📱 设备类型:', isMobile ? '手机端' : '桌面端');
    
    if (isMobile) {
      // === 手机端优先显示策略 ===
      
      // 手机端方式1：查找页面标题区域
      const titleArea = document.querySelector('.page-title, .v-toolbar__title, h1, [class*="title"]');
      if (titleArea) {
        targetContainer = titleArea.parentElement || titleArea;
        displayMode = 'mobile-title';
        console.log('📱 找到手机端目标 - 标题区域');
      }
      
      // 手机端方式2：查找页面内容区域顶部
      if (!targetContainer) {
        const contentArea = document.querySelector('.page-content, .v-content, main, [role="main"]');
        if (contentArea) {
          targetContainer = contentArea;
          displayMode = 'mobile-content';
          console.log('📱 找到手机端目标 - 内容区域');
        }
      }
      
      // 手机端方式3：查找工具栏或导航栏
      if (!targetContainer) {
        const toolbar = document.querySelector('.v-toolbar, .v-app-bar, .toolbar, nav');
        if (toolbar) {
          targetContainer = toolbar;
          displayMode = 'mobile-toolbar';
          console.log('📱 找到手机端目标 - 工具栏');
        }
      }
      
      // 手机端方式4：创建浮动显示
      if (!targetContainer) {
        targetContainer = document.body;
        displayMode = 'mobile-floating';
        console.log('📱 使用手机端浮动显示');
      }
    } else {
      // === 桌面端显示策略 ===
      
      // 桌面端方式1：查找包含特定文本的容器
      const allElements = document.querySelectorAll('*');
      for (let el of allElements) {
        const text = el.textContent;
        if (text && (text.includes('Xinwei Cui') || text.includes('最后编辑') || text.match(/\\d{1,2}\\/\\d{1,2}\\/\\d{4}/))) {
          // 向上查找卡片容器
          let parent = el;
          while (parent && parent.parentElement) {
            if (parent.className && (parent.className.includes('card') || parent.className.includes('elevation'))) {
              targetContainer = parent;
              console.log('🖥️ 找到桌面端目标 - 编辑信息卡片');
              break;
            }
            parent = parent.parentElement;
          }
          if (targetContainer) break;
        }
      }
      
      // 桌面端方式2：直接查找卡片类型的容器
      if (!targetContainer) {
        const cards = document.querySelectorAll('.v-card, .card, [class*="elevation"]');
        for (let card of cards) {
          if (card.textContent && card.textContent.includes('12/')) {
            targetContainer = card;
            console.log('🖥️ 找到桌面端目标 - 日期卡片');
            break;
          }
        }
      }
      
      // 桌面端方式3：查找右侧边栏区域
      if (!targetContainer) {
        const sidebar = document.querySelector('[class*="sidebar"], [class*="side"], .v-navigation-drawer');
        if (sidebar) {
          const cards = sidebar.querySelectorAll('.v-card, .card, [class*="elevation"]');
          if (cards.length > 0) {
            targetContainer = cards[cards.length - 1]; // 选择最后一个卡片
            console.log('🖥️ 找到桌面端目标 - 侧边栏卡片');
          }
        }
      }
    }
    
    if (targetContainer) {
      // 根据不同显示模式创建不同样式的浏览次数显示
      const viewCountEl = document.createElement('div');
      viewCountEl.className = 'wiki-view-count-display';
      
      let htmlContent = '';
      let insertMethod = 'append'; // append | prepend | after
      
      switch (displayMode) {
        case 'mobile-title':
          htmlContent = \`
            <div style="
              display: inline-flex; 
              align-items: center; 
              background: rgba(25, 118, 210, 0.1); 
              padding: 4px 8px; 
              border-radius: 12px; 
              margin: 8px 0; 
              font-size: 12px;
              color: #1976d2;
            ">
              <svg style="width: 14px; height: 14px; margin-right: 4px; fill: currentColor;" viewBox="0 0 24 24">
                <path d="M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z" />
              </svg>
              <span>\${viewCountValue} 次浏览</span>
            </div>
          \`;
          insertMethod = 'after';
          break;
          
        case 'mobile-content':
          htmlContent = \`
            <div style="
              display: flex; 
              align-items: center; 
              justify-content: center;
              background: #f5f5f5; 
              padding: 8px; 
              margin: 0 0 16px 0; 
              border-radius: 8px; 
              font-size: 13px;
              color: #666;
            ">
              <svg style="width: 16px; height: 16px; margin-right: 6px; fill: currentColor;" viewBox="0 0 24 24">
                <path d="M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z" />
              </svg>
              <span>本文已被浏览 <strong style="color: #333;">\${viewCountValue}</strong> 次</span>
            </div>
          \`;
          insertMethod = 'prepend';
          break;
          
        case 'mobile-floating':
          htmlContent = \`
            <div style="
              position: fixed; 
              bottom: 80px; 
              right: 16px; 
              background: rgba(0,0,0,0.8); 
              color: white; 
              padding: 8px 12px; 
              border-radius: 20px; 
              font-size: 12px; 
              z-index: 1000;
              box-shadow: 0 2px 8px rgba(0,0,0,0.3);
              display: flex;
              align-items: center;
            ">
              <svg style="width: 14px; height: 14px; margin-right: 4px; fill: currentColor;" viewBox="0 0 24 24">
                <path d="M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z" />
              </svg>
              <span>\${viewCountValue}</span>
            </div>
          \`;
          break;
          
        default: // 桌面端默认样式
          htmlContent = \`
            <div style="display: flex; align-items: center; padding: 8px 0; margin-top: 8px; border-top: 1px solid #e0e0e0;">
              <svg style="width: 16px; height: 16px; margin-right: 8px; fill: #666;" viewBox="0 0 24 24">
                <path d="M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z" />
              </svg>
              <span style="color: #666; font-size: 14px; font-weight: normal;">浏览次数：<strong style="color: #333;">\${viewCountValue}</strong></span>
            </div>
          \`;
      }
      
      viewCountEl.innerHTML = htmlContent;
      
      // 根据插入方式添加到页面
      if (insertMethod === 'prepend') {
        targetContainer.insertBefore(viewCountEl, targetContainer.firstChild);
      } else if (insertMethod === 'after') {
        if (targetContainer.nextSibling) {
          targetContainer.parentNode.insertBefore(viewCountEl, targetContainer.nextSibling);
        } else {
          targetContainer.parentNode.appendChild(viewCountEl);
        }
      } else {
        targetContainer.appendChild(viewCountEl);
      }
      
      console.log(\`✅ 浏览次数成功添加！设备: \${isMobile ? '手机端' : '桌面端'}，模式: \${displayMode}\`);
      return true;
    } else {
      console.log(\`⏰ 第\${attempts}次未找到合适的容器\${isMobile ? '(手机端)' : '(桌面端)'}，继续尝试...\`);
      if (attempts < maxAttempts) {
        setTimeout(addViewCountToCard, 400);
      } else {
        console.log('❌ 达到最大尝试次数，无法添加浏览次数显示');
      }
      return false;
    }
  }
  
  // 开始执行
  console.log('开始添加浏览次数显示...');
  
  // 多次尝试确保成功
  setTimeout(addViewCountToCard, 100);
  setTimeout(addViewCountToCard, 500);
  setTimeout(addViewCountToCard, 1000);
  setTimeout(addViewCountToCard, 2000);
  setTimeout(addViewCountToCard, 3000);
  
})();

console.log('✅ 浏览次数脚本初始化完成，值:', viewCountValue);
</script>`
        
        injectCode.body = `${injectCode.body}\n${viewCountScript}`

        if (req.query.legacy || req.get('user-agent').indexOf('Trident') >= 0) {
          // -> Convert page TOC
          if (_.isString(page.toc)) {
            page.toc = JSON.parse(page.toc)
          }

          // -> Generate WeChat share image and meta tags for legacy view
          const wechatImage = wechatHelper.getWechatShareImage(page, req)
          _.set(res.locals, 'pageMeta.image', wechatImage)
          const wechatMetaTags = wechatHelper.generateWechatMetaTags(page, WIKI.config, wechatImage)
          
          // -> Construct full page URL for sharing
          const protocol = req.protocol || (req.secure ? 'https' : 'http')
          let host = req.get('host')
          if (host && host.includes('hyzx.heengy.cn')) {
            host = host.replace(':13000', '')
          }
          const fullPageUrl = `${protocol}://${host}${req.originalUrl}`
          
          const shareButton = wechatHelper.generateWechatShareButton(page.id, page.title, description, fullPageUrl)

          // -> Render legacy view
          res.render('legacy/page', {
            page,
            sidebar,
            injectCode,
            isAuthenticated: req.user && req.user.id !== 2,
            wechatMetaTags,
            shareButton
          })
        } else {
          // -> Convert page TOC
          if (!_.isString(page.toc)) {
            page.toc = JSON.stringify(page.toc)
          }

          // -> Inject comments variables
          const commentTmpl = {
            codeTemplate: WIKI.data.commentProvider.codeTemplate,
            head: WIKI.data.commentProvider.head,
            body: WIKI.data.commentProvider.body,
            main: WIKI.data.commentProvider.main
          }
          if (WIKI.config.features.featurePageComments && WIKI.data.commentProvider.codeTemplate) {
            [
              { key: 'pageUrl', value: `${WIKI.config.host}/i/${page.id}` },
              { key: 'pageId', value: page.id }
            ].forEach((cfg) => {
              commentTmpl.head = _.replace(commentTmpl.head, new RegExp(`{{${cfg.key}}}`, 'g'), cfg.value)
              commentTmpl.body = _.replace(commentTmpl.body, new RegExp(`{{${cfg.key}}}`, 'g'), cfg.value)
              commentTmpl.main = _.replace(commentTmpl.main, new RegExp(`{{${cfg.key}}}`, 'g'), cfg.value)
            })
          }

          // -> Page Filename (for edit on external repo button)
          let pageFilename = WIKI.config.lang.namespacing ? `${pageArgs.locale}/${page.path}` : page.path
          pageFilename += page.contentType === 'markdown' ? '.md' : '.html'

          // -> Generate WeChat share image and meta tags
          const wechatImage = wechatHelper.getWechatShareImage(page, req)
          _.set(res.locals, 'pageMeta.image', wechatImage)
          const wechatMetaTags = wechatHelper.generateWechatMetaTags(page, WIKI.config, wechatImage)
          
          // -> Construct full page URL for sharing
          const protocol = req.protocol || (req.secure ? 'https' : 'http')
          let host = req.get('host')
          if (host && host.includes('hyzx.heengy.cn')) {
            host = host.replace(':13000', '')
          }
          const fullPageUrl = `${protocol}://${host}${req.originalUrl}`
          
          const shareButton = wechatHelper.generateWechatShareButton(page.id, page.title, description, fullPageUrl)

          // -> Render view
          res.render('page', {
            page,
            sidebar,
            injectCode,
            comments: commentTmpl,
            effectivePermissions,
            pageFilename,
            wechatMetaTags,
            shareButton
          })
        }
      } else if (pageArgs.path === 'home') {
        _.set(res.locals, 'pageMeta.title', 'Welcome')
        res.render('welcome', { locale: pageArgs.locale })
      } else {
        _.set(res.locals, 'pageMeta.title', 'Page Not Found')
        if (effectivePermissions.pages.write) {
          res.status(404).render('new', { path: pageArgs.path, locale: pageArgs.locale })
        } else {
          res.status(404).render('notfound', { action: 'view' })
        }
      }
    } catch (err) {
      next(err)
    }
  } else {
    if (!WIKI.auth.checkAccess(req.user, ['read:assets'], pageArgs)) {
      return res.sendStatus(403)
    }

    await WIKI.models.assets.getAsset(pageArgs.path, res)
  }
})

module.exports = router
