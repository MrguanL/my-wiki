const { generatePosterHTML } = require('../helpers/poster-frontend')

/**
 * 生成分享海报页面
 */
async function generatePoster(req, res) {
  try {
    const { pageId } = req.params
    console.log('海报API: 请求页面ID:', pageId)
    
    // 将pageId转换为数字
    const numericPageId = parseInt(pageId, 10)
    if (isNaN(numericPageId)) {
      return res.status(400).send(`
        <h1>参数错误</h1>
        <p>页面ID必须是数字: ${pageId}</p>
        <button onclick="window.close()">关闭</button>
      `)
    }
    
    // 获取页面数据
    const page = await WIKI.models.pages.getPageFromDb(numericPageId)
    console.log('海报API: 查询到的页面:', page ? `${page.title} (ID: ${page.id})` : '未找到')
    
    if (!page) {
      return res.status(404).send(`
        <h1>页面不存在</h1>
        <p>未找到ID为 ${pageId} 的页面</p>
        <button onclick="window.close()">关闭</button>
      `)
    }
    
    // 构建页面URL
    let host = req.get('host')
    
    // 外网环境移除端口号
    if (host && host.includes('hyzx.heengy.cn')) {
      host = host.replace(':13000', '')
    }
    
    // 对于外网域名，强制使用HTTPS协议
    const protocol = (host && host.includes('hyzx.heengy.cn')) ? 'https' : (req.protocol || (req.secure ? 'https' : 'http'))
    
    // 构建完整的页面URL
    let pageUrl
    if (WIKI.config.lang.namespacing) {
      // 如果启用了命名空间，需要包含语言代码
      pageUrl = `${protocol}://${host}/${page.localeCode}/${page.path}`
    } else {
      // 没有命名空间，直接使用路径
      pageUrl = `${protocol}://${host}/${page.path}`
    }
    
    // 如果页面路径已经包含了前导斜杠，避免重复
    if (page.path.startsWith('/')) {
      if (WIKI.config.lang.namespacing) {
        pageUrl = `${protocol}://${host}/${page.localeCode}${page.path}`
      } else {
        pageUrl = `${protocol}://${host}${page.path}`
      }
    }
    
    console.log('海报API: 生成的页面URL:', pageUrl)
    
    // 生成海报HTML页面
    const posterHTML = await generatePosterHTML(page, WIKI.config, pageUrl)
    
    // 直接返回HTML页面
    res.set('Content-Type', 'text/html; charset=utf-8')
    res.send(posterHTML)
    
  } catch (error) {
    console.error('生成海报失败:', error)
    res.status(500).send(`
      <h1>海报生成失败</h1>
      <p>错误详情: ${error.message}</p>
      <button onclick="window.close()">关闭</button>
    `)
  }
}

module.exports = {
  generatePoster
} 