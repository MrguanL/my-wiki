const express = require('express')
const router = express.Router()
const crypto = require('crypto')
const moment = require('moment')

/* global WIKI */

/**
 * OA系统SSO API专用控制器
 * 直接处理OA系统的HTTP请求，不经过Passport
 */

// 会话存储
const ssoSessions = new Map()

/**
 * 步骤1: 处理OA系统首次请求 - 返回MD5值
 * GET /auth/oa-api/verify?RCode=xxx
 */
router.get('/verify', async (req, res) => {
  // 设置响应头确保返回JSON
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  
  try {
    const rCode = req.query.RCode
    
    WIKI.logger.info(`OA SSO API - 收到首次请求: ${rCode}, IP: ${req.ip}`)
    
    if (!rCode) {
      WIKI.logger.warn('OA SSO API - 缺少RCode参数')
      return res.status(400).json({
        errorcode: '-1',
        errmsg: 'Missing RCode parameter',
        timestamp: new Date().toISOString()
      })
    }

    // 获取OA配置
    const oaConfig = await getOAConfig()

    // 创建新的会话记录
    const session = {
      timestamp: Date.now(),
      userAgent: req.get('User-Agent'),
      ip: req.ip,
      receivedAt: Date.now()
    }
    
    // 记录SSO会话信息
    ssoSessions.set(rCode, session)

    // 生成MD5加密的(随机码+token)
    const md5Hash = crypto.createHash('md5')
      .update(rCode + oaConfig.token)
      .digest('hex')

    WIKI.logger.info(`OA SSO API - 处理首次请求成功: ${rCode}`)
    
    // 返回JSON响应给OA系统
    res.json({
      errorcode: '0',
      errmsg: 'success',
      RCode: rCode,
      Md5: md5Hash
    })

  } catch (err) {
    WIKI.logger.error(`OA SSO API - 首次请求处理失败: ${err.message}`, err)
    
    // 确保始终返回JSON格式
    if (!res.headersSent) {
      res.status(500).json({
        errorcode: '-500',
        errmsg: `Internal server error: ${err.message}`,
        timestamp: new Date().toISOString(),
        stack: WIKI.IS_DEBUG ? err.stack : undefined
      })
    }
  }
})

/**
 * 步骤2: 处理OA系统二次验证 - 验证用户并登录
 * GET /auth/oa-api/login?RCode=xxx&UserCode=xxx&Md5=xxx&gopage=xxx
 */
router.get('/login', async (req, res) => {
  try {
    const { RCode, UserCode, Md5, gopage, RealName } = req.query
    
    // 记录所有收到的参数，便于调试
    WIKI.logger.info(`OA SSO API - 收到二次验证请求: ${RCode}`)
    WIKI.logger.info(`OA SSO API - 所有参数: ${JSON.stringify(req.query)}`)
    WIKI.logger.info(`OA SSO API - 真实姓名参数: ${RealName || '未提供'}`)
    
    if (!RCode || !UserCode || !Md5) {
      WIKI.logger.warn('OA SSO API - 缺少必要参数')
      return res.status(400).json({
        errorcode: '-1',
        errmsg: 'Missing required parameters (RCode, UserCode, Md5)',
        timestamp: new Date().toISOString()
      })
    }

    // 获取OA配置
    const oaConfig = await getOAConfig()

    // 验证随机码
    const session = ssoSessions.get(RCode)
    if (!session) {
      WIKI.logger.warn(`OA SSO API - 无效的RCode: ${RCode}`)
      return res.status(400).json({
        errorcode: '-2',
        errmsg: 'Invalid RCode - session not found',
        timestamp: new Date().toISOString()
      })
    }

    // 检查超时
    const currentTime = Date.now()
    if (currentTime - (session.receivedAt || session.timestamp) > oaConfig.timeoutSeconds * 1000) {
      ssoSessions.delete(RCode)
      WIKI.logger.warn(`OA SSO API - 会话超时: ${RCode}`)
      return res.status(400).json({
        errorcode: '-3',
        errmsg: 'SSO session expired',
        timestamp: new Date().toISOString()
      })
    }

    // Base64解码工号
    const userCodeDecoded = Buffer.from(UserCode, 'base64').toString('utf8')
    
    // 验证MD5: md5(随机码+工号+token)
    const expectedMd5 = crypto.createHash('md5')
      .update(RCode + userCodeDecoded + oaConfig.token)
      .digest('hex')

    if (Md5.toLowerCase() !== expectedMd5.toLowerCase()) {
      ssoSessions.delete(RCode)
      WIKI.logger.warn(`OA SSO API - MD5验证失败: ${RCode}, 用户: ${userCodeDecoded}`)
      return res.status(400).json({
        errorcode: '-4',
        errmsg: 'Invalid MD5 signature',
        timestamp: new Date().toISOString()
      })
    }

    // 清理会话
    ssoSessions.delete(RCode)

    // 处理gopage参数 (URL解码)
    let targetPage = oaConfig.defaultHomePage || '/'
    if (gopage) {
      targetPage = decodeURIComponent(gopage)
        .replace(/%26/g, '&')
        .replace(/%3F/g, '?')
    }

    // 解码真实姓名（支持多种参数名）
    let realName = null
    const nameParams = ['RealName', 'Name', 'DisplayName', 'UserName', 'FullName']
    
    for (const paramName of nameParams) {
      if (req.query[paramName]) {
        const nameValue = req.query[paramName]
        WIKI.logger.info(`OA SSO API - 找到姓名参数 ${paramName}: ${nameValue}`)
        
        try {
          // 尝试Base64解码
          realName = Buffer.from(nameValue, 'base64').toString('utf8')
          WIKI.logger.info(`OA SSO API - 解码真实姓名: ${realName}`)
          break
        } catch (decodeErr) {
          // 如果Base64解码失败，直接使用原值
          WIKI.logger.warn(`OA SSO API - Base64解码失败，使用原值: ${nameValue}`)
          realName = nameValue
          break
        }
      }
    }
    
    if (!realName) {
      WIKI.logger.info(`OA SSO API - 未找到任何姓名参数，将使用工号作为显示名`)
    }
    
    // 查找或创建用户
    const user = await processUser(userCodeDecoded, realName)
    
    WIKI.logger.info(`OA SSO API - 用户认证成功: ${userCodeDecoded}`)
    
    // 确保用户有用户组信息
    const userWithGroups = await WIKI.models.users.query()
      .findById(user.id)
      .withGraphFetched('groups')
      .modifyGraph('groups', builder => {
        builder.select('groups.id', 'permissions')
      })
    
    // 生成用户Token
    const jwtToken = await WIKI.models.users.refreshToken(userWithGroups)
    
    WIKI.logger.info(`OA SSO API - 用户登录成功，设置JWT token并重定向到: ${targetPage}`)
    
    // 设置JWT token cookie（与标准认证流程保持一致）
    res.cookie('jwt', jwtToken.token, { 
      expires: moment().add(1, 'y').toDate()
    })
    
    // 重定向到目标页面
    res.redirect(targetPage)

  } catch (err) {
    ssoSessions.delete(req.query.RCode)
    WIKI.logger.error(`OA SSO API - 二次验证失败: ${err.message}`)
    // 在发生错误时，重定向到登录页面而不是返回JSON
    res.redirect('/login?error=' + encodeURIComponent(err.message))
  }
})

/**
 * 获取OA系统配置
 */
async function getOAConfig() {
  try {
    WIKI.logger.info('开始查询OA配置...')
    
    const authProvider = await WIKI.models.authentication.query()
      .where('key', 'oasystem')
      .where('isEnabled', true)
      .first()
    
    if (authProvider) {
      WIKI.logger.info(`找到OA配置: ${JSON.stringify(authProvider.config)}`)
      return authProvider.config
    } else {
      WIKI.logger.warn('未找到启用的OA认证配置，使用默认配置')
      // 使用默认配置作为降级方案
      return {
        systemName: 'Wiki',
        systemId: 'WIKI', 
        token: 'hyxn_hyzx',
        timeoutSeconds: 300,
        defaultHomePage: '/'
      }
    }
  } catch (err) {
    WIKI.logger.error('查询OA配置失败:', err)
    // 出错时也使用默认配置
    return {
      systemName: 'Wiki',
      systemId: 'WIKI',
      token: 'hyxn_hyzx', 
      timeoutSeconds: 300,
      defaultHomePage: '/'
    }
  }
}

/**
 * 处理用户信息
 * @param {string} userCode - 用户工号
 * @param {string} realName - 真实姓名（可选）
 */
async function processUser(userCode, realName = null) {
  try {
    WIKI.logger.info(`开始处理用户: ${userCode}, 真实姓名: ${realName || '未提供'}`)
    
    // 获取实际的providerKey
    const authProvider = await WIKI.models.authentication.query()
      .where('strategyKey', 'oasystem')
      .where('isEnabled', true)
      .first()
    
    const actualProviderKey = authProvider ? authProvider.key : null
    
    if (!actualProviderKey) {
      WIKI.logger.warn(`未找到启用的OA认证策略，用户 ${userCode} 将无法创建`)
      throw new Error('OA authentication strategy not found or not enabled')
    }
    
    // 使用工号构造最简email格式（满足格式验证但保持简洁）
    const email = `${userCode}@oa`
    
    // 首先检查用户是否已存在（通过providerId或email查找）
    let user = await WIKI.models.users.query().findOne({
      providerId: userCode,
      providerKey: actualProviderKey
    })
    
    // 如果通过providerId没找到，尝试通过email查找
    if (!user) {
      user = await WIKI.models.users.query().findOne({ email: email })
      
      // 如果通过email找到了用户，更新其provider信息
      if (user) {
        await WIKI.models.users.query().findById(user.id).patch({
          providerId: userCode,
          providerKey: actualProviderKey,
          isActive: true,
          isVerified: true
        })
        WIKI.logger.info(`通过email找到用户并更新provider信息: ${userCode}`)
      }
    }
    
    if (user) {
      WIKI.logger.info(`找到已存在用户: ${userCode}`)
      // 确保用户是激活状态，并更新姓名和email格式
      const updateData = { 
        isActive: true,
        email: email // 确保email格式正确
      }
      

      
      if (realName) {
        updateData.name = realName
      }
      
      await WIKI.models.users.query().findById(user.id).patch(updateData)
      user.isActive = true
      user.email = email
      if (realName) {
        user.name = realName
      }
      return user
    }
    
    // 用户不存在，创建新用户
    WIKI.logger.info(`创建新用户: ${userCode}`)
    
    // 确保有真实姓名，否则提示需要配置
    if (!realName) {
      WIKI.logger.warn(`OA用户 ${userCode} 没有提供真实姓名，将使用工号作为显示名。建议OA系统传递RealName参数。`)
    }
    const displayName = realName || `用户${userCode}` // 如果没有真实姓名，显示为"用户23130"
    
    // 获取合适的用户组 - OA用户使用只读权限组
    let defaultGroup = null
    
    // 优先级1: 查找OA用户专用组（只读权限）
    defaultGroup = await WIKI.models.groups.query().findOne({ name: 'OA Viewers' })
    
    // 优先级2: 查找只读用户组
    if (!defaultGroup) {
      defaultGroup = await WIKI.models.groups.query().findOne({ name: 'Read Only' })
    }
    
    // 优先级3: 查找查看者组
    if (!defaultGroup) {
      defaultGroup = await WIKI.models.groups.query().findOne({ name: 'Viewers' })
    }
    
    // 优先级4: 查找访客组（通常权限较低）
    if (!defaultGroup) {
      defaultGroup = await WIKI.models.groups.query().findOne({ name: 'Guest' })
    }
    
    // 如果以上都没有，创建一个专用的OA查看者组
    if (!defaultGroup) {
      WIKI.logger.info('未找到合适的只读用户组，创建OA专用组...')
      
      try {
        // 创建OA专用用户组
        defaultGroup = await WIKI.models.groups.query().insert({
          name: 'OA Viewers',
          isSystem: false,
          redirectOnLogin: '/',
          permissions: JSON.stringify([
            'read:pages',
            'read:assets', 
            'read:comments',
            'write:comments'
          ]),
          pageRules: JSON.stringify([
            {
              id: 'default',
              deny: false,
              match: 'START',
              roles: ['read:pages', 'read:assets', 'read:comments', 'write:comments'],
              path: '',
              locales: []
            }
          ]),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        })
        
        WIKI.logger.info(`成功创建OA专用用户组: ${defaultGroup.name} (ID: ${defaultGroup.id})`)
      } catch (createErr) {
        WIKI.logger.error('创建OA用户组失败:', createErr)
        // 兜底：使用第一个可用的组
        defaultGroup = await WIKI.models.groups.query().first()
      }
    }
    
    WIKI.logger.info(`为OA用户 ${userCode} 分配只读权限用户组: ${defaultGroup ? defaultGroup.name : '无'}`)
    
    // 创建全新用户
    const newUser = await WIKI.models.users.query().insert({
      providerId: userCode,
      providerKey: actualProviderKey,
      email: email,
      name: displayName, // 使用真实姓名或工号
      pictureUrl: '',
      isActive: true,
      isVerified: true,
      mustChangePwd: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    })
    
    // 分配用户组
    if (defaultGroup) {
      await WIKI.models.knex('userGroups').insert({
        userId: newUser.id,
        groupId: defaultGroup.id
      })
      
      WIKI.logger.info(`成功为OA用户 ${userCode} 分配只读权限组: ${defaultGroup.name} (ID: ${defaultGroup.id})`)
    } else {
      WIKI.logger.warn(`OA用户 ${userCode} 未分配到任何用户组，将无法访问内容`)
    }
    
    WIKI.logger.info(`成功创建新用户: ${userCode}, ID: ${newUser.id}`)
    return newUser
    
  } catch (err) {
    WIKI.logger.error(`处理用户失败: ${userCode}, 错误: ${err.message}`, err)
    throw new Error(`Failed to process user: ${err.message}`)
  }
}

/**
 * 清理过期会话的定时任务
 */
const cleanup = () => {
  const currentTime = Date.now()
  const timeoutMs = 300 * 1000 // 5分钟超时
  
  for (const [rCode, session] of ssoSessions.entries()) {
    if (currentTime - session.timestamp > timeoutMs) {
      ssoSessions.delete(rCode)
    }
  }
}

// 每分钟清理一次过期会话
setInterval(cleanup, 60000)



module.exports = router 