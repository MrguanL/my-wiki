const express = require('express')
const router = express.Router()
const crypto = require('crypto')
const ms = require('ms')

/* global WIKI */

/**
 * OA系统SSO专用API控制器
 * 处理OA系统的HTTP GET请求
 */

/**
 * 健康检查接口
 * GET /auth/oa/health
 */
router.get('/health', (req, res) => {
  res.json({
    errorcode: '0',
    errmsg: 'OA SSO service is running',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  })
})

/**
 * 获取系统信息接口 (用于OA系统配置验证)
 * GET /auth/oa/info
 */
router.get('/info', async (req, res) => {
  try {
    // 检查OA SSO是否已配置
    const oaConfig = await getOAConfig()
    
    res.json({
      errorcode: '0',
      errmsg: 'success',
      data: {
        systemName: oaConfig ? oaConfig.systemName : 'Wiki.js Knowledge Base',
        systemId: oaConfig ? oaConfig.systemId : 'WIKI',
        configured: !!oaConfig,
        endpoints: {
          sso1: '/auth/oa/step1',
          sso2: '/auth/oa/step2',
          health: '/auth/oa/health'
        }
      }
    })
  } catch (err) {
    WIKI.logger.error('OA SSO Info Error:', err)
    res.status(500).json({
      errcode: '-1',
      errmsg: `Failed to get system info: ${err.message}`
    })
  }
})

/**
 * 测试接口 - 用于OA系统对接测试
 * GET /auth/oa/test?token=xxx
 */
router.get('/test', async (req, res) => {
  try {
    const { token } = req.query
    const oaConfig = await getOAConfig()
    
    if (!oaConfig) {
      return res.json({
        errcode: '-1',
        errmsg: 'OA SSO not configured'
      })
    }
    
    // 简单的token验证测试
    const testString = 'test123'
    const expectedMd5 = crypto.createHash('md5')
      .update(testString + oaConfig.token)
      .digest('hex')
    
    const providedMd5 = token ? crypto.createHash('md5')
      .update(testString + token)
      .digest('hex') : ''
    
    res.json({
      errorcode: '0',
      errmsg: 'test completed',
      data: {
        testString: testString,
        expectedMd5: expectedMd5,
        providedMd5: providedMd5,
        tokenMatch: expectedMd5 === providedMd5,
        timestamp: new Date().toISOString()
      }
    })
    
  } catch (err) {
    WIKI.logger.error('OA SSO Test Error:', err)
    res.status(500).json({
      errcode: '-1',
      errmsg: `Test failed: ${err.message}`
    })
  }
})

/**
 * 获取OA系统配置
 */
async function getOAConfig() {
  try {
    const authProvider = await WIKI.models.authentication.query()
      .where('key', 'oasystem')
      .where('isEnabled', true)
      .first()
    
    return authProvider ? authProvider.config : null
  } catch (err) {
    WIKI.logger.error('Failed to get OA config:', err)
    return null
  }
}

/**
 * 错误处理中间件
 */
router.use((err, req, res, next) => {
  WIKI.logger.error('OA SSO Controller Error:', err)
  res.status(500).json({
    errcode: '-1',
    errmsg: 'Internal server error'
  })
})

module.exports = router 