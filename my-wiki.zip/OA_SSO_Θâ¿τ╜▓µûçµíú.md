# Wiki.js OA系统SSO集成部署文档

## 📋 概述

本文档介绍如何在Wiki.js中集成您的OA系统的自定义SSO协议，实现双向验证的安全单点登录。

## 🚀 快速开始

### 🔧 安装步骤

#### 1. 文件已就绪
所需的模块文件已创建完成：
- ✅ `server/modules/authentication/oasystem/definition.yml` - 认证模块定义
- ✅ `server/modules/authentication/oasystem/authentication.js` - 认证逻辑实现
- ✅ `server/controllers/auth-oa.js` - API控制器
- ✅ `server/master.js` - 路由已注册

#### 2. 重启Wiki.js服务

```bash
# 在Wiki.js根目录执行
npm restart
# 或者
pm2 restart wiki
```

### ⚙️ 配置步骤

#### 1. 登录Wiki.js管理后台

访问：`http://localhost:3000/_admin`

#### 2. 配置OA SSO认证策略

1. 进入 **设置** → **认证**
2. 点击 **添加策略**
3. 选择 **OA System SSO**
4. 填写配置参数：

| 参数名称 | 配置说明 | 示例值 |
|---------|----------|--------|
| **异构系统名称** | 在OA中显示的系统名称 | `Wiki知识库系统` |
| **异构系统标识** | 系统唯一标识符 | `WIKI` |
| **OA系统访问地址** | OA系统的完整URL | `http://oa.company.com` |
| **SSO地址1** | 首次请求相对路径 | `/login/oasystem` |
| **SSO地址2** | 二次请求相对路径 | `/login/oasystem/callback` |
| **Token密钥** | 双方约定的共享密钥 | `your-shared-secret-key` |
| **超时时间** | 验证超时时间(秒) | `300` |
| **默认首页路径** | 登录成功后跳转页面 | `/` |

#### 3. 启用策略

保存配置并将策略状态设置为**启用**。

## 🔗 OA系统配置

### 在OA系统后台添加异构系统配置：

| 配置项 | 值 | 说明 |
|--------|-----|------|
| **异构系统名称** | `Wiki知识库系统` | 显示名称 |
| **异构系统标识** | `WIKI` | 必须与Wiki.js配置一致 |
| **异构系统访问IP/域名** | `your-wiki-domain.com` | Wiki.js的域名 |
| **异构系统SSO地址1** | `/login/oasystem` | 首次请求地址 |
| **异构系统SSO地址2** | `/login/oasystem/callback` | 回调验证地址 |
| **Token** | `your-shared-secret-key` | 必须与Wiki.js配置一致 |

## 🔄 SSO工作流程

### 详细的认证流程：

```mermaid
sequenceDiagram
    participant User as 用户
    participant Wiki as Wiki.js
    participant OA as OA系统

    User->>Wiki: 访问Wiki.js页面
    Wiki->>Wiki: 生成随机码(RCode)
    Wiki->>OA: 重定向到OA登录<br/>?RCode=随机码
    OA->>OA: 用户登录验证
    OA->>Wiki: 发起首次请求<br/>?RCode=随机码
    Wiki->>Wiki: 验证随机码有效性
    Wiki->>Wiki: 生成MD5(RCode+Token)
    Wiki->>OA: 返回{RCode, Md5}
    OA->>OA: 验证MD5正确性
    OA->>Wiki: 发起二次验证<br/>?RCode&UserCode&Md5&gopage
    Wiki->>Wiki: 验证所有参数
    Wiki->>Wiki: 创建/更新用户
    Wiki->>User: 登录成功，跳转目标页面
```

### 请求示例：

**步骤1 - 用户访问：**
```
GET http://wiki.company.com/login/oasystem
```

**步骤2 - OA发起首次请求：**
```
GET http://wiki.company.com/login/oasystem?RCode=1234567890_abcdef
```

**步骤3 - Wiki.js响应：**
```json
{
  "errorcode": "0",
  "errmsg": "success",
  "RCode": "1234567890_abcdef",
  "Md5": "5d41402abc4b2a76b9719d911017c592"
}
```

**步骤4 - OA发起二次验证：**
```
GET http://wiki.company.com/login/oasystem/callback?RCode=1234567890_abcdef&UserCode=dGVzdA==&Md5=098f6bcd4621d373cade4e832627b4f6&gopage=%2F
```

## 📡 API接口文档

### 健康检查接口

```http
GET /auth/oa/health
```

**响应示例：**
```json
{
  "errorcode": "0",
  "errmsg": "OA SSO service is running",
  "timestamp": "2024-01-01T12:00:00.000Z",
  "version": "1.0.0"
}
```

### 系统信息接口

```http
GET /auth/oa/info
```

**响应示例：**
```json
{
  "errorcode": "0",
  "errmsg": "success",
  "data": {
    "systemName": "Wiki知识库系统",
    "systemId": "WIKI",
    "configured": true,
    "endpoints": {
      "sso1": "/auth/oa/step1",
      "sso2": "/auth/oa/step2",
      "health": "/auth/oa/health"
    }
  }
}
```

### 测试接口

```http
GET /auth/oa/test?token=your-token
```

**响应示例：**
```json
{
  "errorcode": "0",
  "errmsg": "test completed",
  "data": {
    "testString": "test123",
    "expectedMd5": "5d41402abc4b2a76b9719d911017c592",
    "providedMd5": "5d41402abc4b2a76b9719d911017c592",
    "tokenMatch": true,
    "timestamp": "2024-01-01T12:00:00.000Z"
  }
}
```

## 🛠️ 高级配置

### 用户信息映射

修改 `server/modules/authentication/oasystem/authentication.js` 中的用户处理逻辑：

```javascript
// 在 processUser 方法中自定义用户信息映射
Strategy.prototype.processUser = async function(userCode, req) {
  try {
    // 示例：从HR系统获取用户信息
    const userInfo = await getFromHRSystem(userCode)
    
    const user = await WIKI.models.users.processProfile({
      providerKey: req.params.strategy,
      profile: {
        id: userCode,
        email: userInfo.email || `${userCode}@company.com`,
        displayName: userInfo.name || userCode,
        picture: userInfo.avatar || ''
      }
    })
    
    // 处理用户组映射
    if (userInfo.departments) {
      for (const dept of userInfo.departments) {
        const group = await WIKI.models.groups.query()
          .where('name', dept).first()
        if (group) {
          await user.$relatedQuery('groups').relate(group.id)
        }
      }
    }
    
    return user
  } catch (err) {
    throw new Error(`Failed to process user: ${err.message}`)
  }
}
```

### 安全增强配置

#### 1. IP白名单验证
```javascript
// 在 authentication.js 中添加IP验证
const allowedIPs = ['192.168.1.100', '10.0.0.50'] // OA服务器IP

Strategy.prototype.validateSourceIP = function(req) {
  const clientIP = req.ip || req.connection.remoteAddress
  return allowedIPs.includes(clientIP)
}
```

#### 2. 请求签名验证
```javascript
// 增强的MD5验证，包含时间戳
const timestamp = Math.floor(Date.now() / 1000)
const signature = crypto.createHash('md5')
  .update(RCode + userCode + timestamp + conf.token)
  .digest('hex')
```

## 🔍 故障排查

### 常见问题及解决方案

#### 1. **随机码验证失败**
```bash
# 检查日志
tail -f data/wiki.log | grep "OA SSO"

# 可能原因：
# - 超时设置过短
# - 时间不同步
# - 随机码重复使用
```

#### 2. **MD5验证失败**
```bash
# 验证token配置
curl "http://your-wiki-domain.com/auth/oa/test?token=your-token"

# 检查编码问题
# - 确保UTF-8编码
# - 检查特殊字符处理
# - 验证Base64编码正确性
```

#### 3. **用户创建失败**
```bash
# 检查用户配置
grep -i "processUser" data/wiki.log

# 可能原因：
# - 邮箱格式不正确
# - 用户名重复
# - 权限不足
```

### 调试模式

启用详细日志记录：

```javascript
// 在 authentication.js 开头添加
const DEBUG = process.env.NODE_ENV === 'development'

// 在关键位置添加调试日志
if (DEBUG) {
  WIKI.logger.debug(`OA SSO Debug: ${JSON.stringify({
    rCode,
    userCode,
    timestamp: new Date().toISOString()
  })}`)
}
```

### 监控和告警

#### 设置监控脚本：
```bash
#!/bin/bash
# monitor-oa-sso.sh

HEALTH_URL="http://your-wiki-domain.com/auth/oa/health"
RESPONSE=$(curl -s $HEALTH_URL)

if [[ $RESPONSE == *"errorcode\":\"0\""* ]]; then
    echo "OA SSO健康状态正常"
else
    echo "⚠️ OA SSO服务异常，请检查！"
    # 发送告警邮件或消息
fi
```

## 🔒 安全注意事项

### 必要的安全措施：

1. **通信安全**
   - ✅ 生产环境必须使用HTTPS
   - ✅ 配置SSL证书
   - ✅ 启用HSTS

2. **Token安全**
   - ✅ 使用强随机Token (至少32位)
   - ✅ 定期轮换Token密钥
   - ✅ 避免Token泄露到日志

3. **会话安全**
   - ✅ 设置合理超时时间 (推荐5分钟)
   - ✅ 定期清理过期会话
   - ✅ 限制会话并发数

4. **访问控制**
   - ✅ 配置OA服务器IP白名单
   - ✅ 监控异常访问模式
   - ✅ 记录所有SSO事件

## 🚀 部署清单

### 上线前检查项：

- [ ] OA SSO模块已正确安装
- [ ] 配置参数已填写并验证
- [ ] 健康检查接口正常响应
- [ ] 测试接口Token验证通过
- [ ] 用户信息映射逻辑正确
- [ ] 日志记录配置完整
- [ ] SSL证书已配置
- [ ] 监控脚本已部署

### 性能优化：

- [ ] 启用Redis缓存会话数据
- [ ] 配置负载均衡器
- [ ] 优化数据库连接池
- [ ] 设置CDN加速

## 📞 技术支持

### 联系方式：
- **技术支持**: tech-support@company.com
- **开发团队**: dev-team@company.com
- **紧急联系**: +86-400-xxx-xxxx

### 文档版本：
- **版本**: 2.0.0
- **更新时间**: 2024-01-15
- **适用版本**: Wiki.js 2.5+
- **兼容性**: Node.js 10.12+

---

## 📝 变更日志

### v2.0.0 (2024-01-15)
- ✨ 完整实现OA系统SSO协议
- 🔧 添加详细的API文档
- 🛡️ 增强安全配置选项
- 📊 添加监控和调试功能

### v1.0.0 (2024-01-01)
- 🎉 初始版本发布 